/* Rasd dashboard – vanilla JS, no build step. */
(() => {
  "use strict";

  const T = {
    ar: {
      appName: "رصد", appAlt: "Rasd", tagline: "الكشف المبكر عن روابط ومواقع الاحتيال المالي", settings: "الإعدادات",
      heroTitle: "فحص شامل بضغطة زر واحدة",
      heroSub: "يبحث رصد في سجلات شهادات الأمان، والنطاقات المشابهة للمواقع الرسمية، ونتائج محركات البحث، وخرائط Google — ثم يحلّل كل موقع ويعطيه درجة خطورة مع الأسباب.",
      stCt: "سجلات الشهادات", stTypo: "النطاقات المشابهة", stSearch: "محركات البحث", stMaps: "خرائط Google",
      btnFull: "ابدأ الفحص الشامل", stop: "إيقاف", running: "جارٍ الفحص…",
      urlsLabel: "روابط محددة لفحصها (اختياري — رابط في كل سطر، أو الصق رسالة SMS كاملة)",
      btnCheck: "فحص هذه الروابط فقط", liveLog: "سجل التنفيذ المباشر",
      sTotal: "رابطاً تم تحليله", sFraud: "احتيالي على الأرجح", sSusp: "مشبوه", sLow: "منخفض الخطورة / رسمي",
      fAll: "الكل", fFraud: "احتيالي", fSusp: "مشبوه", fLow: "منخفض", filterPh: "بحث في النتائج…",
      report: "تقرير PDF", thScore: "الخطورة", thSite: "الموقع", thSource: "المصدر", thReason: "أبرز سبب", thAge: "عمر النطاق",
      empty: "لا توجد نتائج بعد. اضغط «ابدأ الفحص الشامل».",
      footer: "رصد — نموذج أولي لهاكاثون ScamShield AI. الدرجات تقديرات آلية تحتاج مراجعة بشرية قبل أي إجراء.",
      settingsTitle: "الإعدادات ومفاتيح الربط (اختيارية)",
      settingsHint: "البرنامج يعمل بدون أي مفاتيح. كل مفتاح يضيف مصدراً إضافياً. تُحفظ المفاتيح على جهازك فقط.",
      kSerp: "— نتائج Google والإعلانات وخرائط Google", kGsb: "— قائمة Google للمواقع الضارة",
      kVt: "— تقييم 70+ محرك أمني", kAi: "— مراجعة الصفحات بالذكاء الاصطناعي", kModel: "نموذج Claude",
      save: "حفظ", close: "إغلاق", saved: "تم حفظ الإعدادات", keySet: "•••• محفوظ (اتركه فارغاً للإبقاء عليه)",
      steps: { ct: "الشهادات", typosquat: "المشابهة", search: "البحث", maps: "الخرائط", analyze: "التحليل", done: "اكتمل" },
      src: { manual: "يدوي", ct: "سجلات الشهادات", typosquat: "نطاق مشابه", search: "بحث", search_ad: "إعلان بحث", maps: "خرائط" },
      days: "يوماً", years: "سنة", noUrls: "اكتب رابطاً واحداً على الأقل", history: "سجل الفحوصات السابقة",
      current: "— الفحص الحالي —", reasons: "الأدلة والأسباب", evidence: "بيانات تقنية", noReasons: "لا توجد مؤشرات خطر.",
      copyUrl: "نسخ الرابط (معطّل)", copyCase: "نسخ ملخص للبلاغ", openReport: "تقرير الفحص الكامل", copied: "تم النسخ",
      kvDomain: "النطاق المسجّل", kvFinal: "الوجهة النهائية", kvIps: "عناوين IP", kvCreated: "تاريخ التسجيل",
      kvRegistrar: "المسجّل", kvTls: "شهادة الأمان", kvTitle: "عنوان الصفحة", kvStatus: "رمز الاستجابة",
      kvSeen: "أول رصد", kvContext: "سياق الاكتشاف", kvMl: "نموذج التعلم الآلي", kvVt: "VirusTotal", kvAi: "مراجعة الذكاء الاصطناعي",
      kvErrors: "ملاحظات", ml: "نموذج ML", trustNote: "مؤشرات ثقة", score: "درجة الخطورة",
      intSerp: "Google/Maps", intGsb: "Safe Browsing", intVt: "VirusTotal", intAi: "Claude AI", intMl: "نموذج ML",
    },
    en: {
      appName: "Rasd", appAlt: "رصد", tagline: "Early detection of fraudulent links and websites", settings: "Settings",
      heroTitle: "Full scan with one click",
      heroSub: "Rasd searches Certificate Transparency logs, look-alike domains of official sites, search-engine results and Google Maps — then analyses every site and gives it a risk score with reasons.",
      stCt: "Certificate logs", stTypo: "Look-alike domains", stSearch: "Search engines", stMaps: "Google Maps",
      btnFull: "Start full scan", stop: "Stop", running: "Scanning…",
      urlsLabel: "Specific links to check (optional — one per line, or paste a whole SMS message)",
      btnCheck: "Check these links only", liveLog: "Live execution log",
      sTotal: "links analysed", sFraud: "likely fraud", sSusp: "suspicious", sLow: "low risk / official",
      fAll: "All", fFraud: "Fraud", fSusp: "Suspicious", fLow: "Low", filterPh: "Search results…",
      report: "PDF report", thScore: "Risk", thSite: "Website", thSource: "Source", thReason: "Top reason", thAge: "Domain age",
      empty: "No results yet. Press “Start full scan”.",
      footer: "Rasd — ScamShield AI hackathon prototype. Scores are automated estimates and need human review before action.",
      settingsTitle: "Settings & API keys (optional)",
      settingsHint: "Rasd works without any keys. Each key adds an extra source. Keys are stored only on this computer.",
      kSerp: "— Google results, ads and Google Maps", kGsb: "— Google's dangerous-site list",
      kVt: "— 70+ security engines", kAi: "— AI review of page content", kModel: "Claude model",
      save: "Save", close: "Close", saved: "Settings saved", keySet: "•••• saved (leave empty to keep)",
      steps: { ct: "Cert logs", typosquat: "Look-alikes", search: "Search", maps: "Maps", analyze: "Analysis", done: "Done" },
      src: { manual: "Manual", ct: "Cert logs", typosquat: "Look-alike", search: "Search", search_ad: "Search ad", maps: "Maps" },
      days: "days", years: "years", noUrls: "Enter at least one link", history: "Previous scans",
      current: "— current scan —", reasons: "Evidence & reasons", evidence: "Technical data", noReasons: "No risk indicators.",
      copyUrl: "Copy URL (defanged)", copyCase: "Copy case summary", openReport: "Full scan report", copied: "Copied",
      kvDomain: "Registered domain", kvFinal: "Final URL", kvIps: "IP addresses", kvCreated: "Registered on",
      kvRegistrar: "Registrar", kvTls: "TLS certificate", kvTitle: "Page title", kvStatus: "HTTP status",
      kvSeen: "First seen", kvContext: "Discovery context", kvMl: "ML model", kvVt: "VirusTotal", kvAi: "AI review",
      kvErrors: "Notes", ml: "ML model", trustNote: "Trust indicators", score: "Risk score",
      intSerp: "Google/Maps", intGsb: "Safe Browsing", intVt: "VirusTotal", intAi: "Claude AI", intMl: "ML model",
    },
  };

  const STEP_ORDER = ["ct", "typosquat", "search", "maps", "analyze", "done"];
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const defang = (u) => String(u || "").replace(/^http/i, "hxxp").replace(/\./g, "[.]");

  const state = {
    lang: localStorageGet("rasd_lang") || "ar",
    jobId: null, scanId: null, kind: "full", since: 0, timer: null,
    results: [], seen: new Set(), filter: "all", q: "", status: null, stages: {},
  };

  function localStorageGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
  function localStorageSet(k, v) { try { localStorage.setItem(k, v); } catch { /* preview */ } }
  const t = (k) => T[state.lang][k] ?? k;

  // ------------------------------------------------------------------ i18n
  function applyLang() {
    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === "ar" ? "rtl" : "ltr";
    document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll("[data-i18n-ph]").forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
    $("btnLang").textContent = state.lang === "ar" ? "English" : "العربية";
    if (state.status) renderIntegrations();
    renderSteps(state.lastStage, state.lastJobStatus);
    renderResults();
    loadHistory();
  }

  // ------------------------------------------------------------------ API
  async function api(path, opts = {}) {
    const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...opts });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || res.statusText);
    return res.json();
  }

  async function loadStatus() {
    state.status = await api("/api/status");
    renderIntegrations();
  }

  function renderIntegrations() {
    const s = state.status.settings;
    const items = [["intSerp", s.serpapi_key], ["intGsb", s.gsb_key], ["intVt", s.vt_key], ["intAi", s.anthropic_key], ["intMl", state.status.ml_model]];
    $("integrations").innerHTML = items.map(([k, on]) => `<span class="chip ${on ? "on" : "off"}">${esc(t(k))}</span>`).join("");
  }

  async function loadHistory() {
    try {
      const scans = await api("/api/scans");
      const sel = $("history");
      const opts = [`<option value="">${esc(t("history"))}</option>`];
      scans.forEach((s) => {
        const v = (s.summary && s.summary.verdicts) || {};
        const d = new Date(s.started_at);
        const when = isNaN(d) ? "" : d.toLocaleString(state.lang === "ar" ? "ar-AE" : "en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
        const total = (s.summary && s.summary.total) || 0;
        opts.push(`<option value="${esc(s.id)}" ${s.id === state.scanId ? "selected" : ""}>${s.kind === "full" ? "⚡" : "🔎"} ${esc(when)} · ${v.fraud || 0} ⚠ / ${total}</option>`);
      });
      sel.innerHTML = opts.join("");
    } catch { /* ignore */ }
  }

  // ------------------------------------------------------------------ scanning
  function selectedStages() {
    const st = {};
    document.querySelectorAll("#stages input").forEach((i) => { st[i.value] = i.checked; });
    return st;
  }

  async function start(kind) {
    const urls = $("urls").value;
    if (kind === "check" && !urls.trim()) { toast(t("noUrls")); return; }
    state.kind = kind; state.stages = kind === "full" ? selectedStages() : {};
    const job = await api(`/api/scan/${kind}`, { method: "POST", body: JSON.stringify({ urls, stages: state.stages }) });
    state.jobId = job.job_id; state.scanId = job.job_id; state.since = 0;
    state.results = []; state.seen = new Set();
    $("log").innerHTML = "";
    setRunning(true);
    renderResults();
    poll();
  }

  function setRunning(on) {
    $("btnFull").disabled = on; $("btnCheck").disabled = on;
    $("btnStop").classList.toggle("hidden", !on);
    $("progressCard").classList.remove("hidden");
    $("btnFull").querySelector("[data-i18n]").textContent = on ? t("running") : t("btnFull");
    $("btnReport").disabled = on || !state.scanId; $("btnCsv").disabled = on || !state.scanId;
  }

  async function poll() {
    clearTimeout(state.timer);
    if (!state.jobId) return;
    let snap;
    try { snap = await api(`/api/jobs/${state.jobId}?since=${state.since}`); }
    catch { state.timer = setTimeout(poll, 1500); return; }
    state.since = snap.log_count;
    const log = $("log");
    snap.logs.forEach((l) => {
      const d = document.createElement("div");
      d.innerHTML = `<span>${esc(l.t)}</span>${esc(state.lang === "ar" ? l.ar : l.en)}`;
      d.dataset.ar = l.ar; d.dataset.en = l.en; d.dataset.t = l.t;
      log.appendChild(d);
    });
    if (snap.logs.length) log.scrollTop = log.scrollHeight;
    $("bar").style.width = snap.progress + "%";
    state.lastStage = snap.stage; state.lastJobStatus = snap.status;
    renderSteps(snap.stage, snap.status);
    state.results = snap.results;
    renderResults();
    if (snap.status === "running") state.timer = setTimeout(poll, 900);
    else { setRunning(false); loadHistory(); }
  }

  function renderSteps(stage, status) {
    const box = $("steps");
    const order = state.kind === "check" ? ["analyze", "done"] : STEP_ORDER;
    const idx = order.indexOf(stage);
    box.style.gridTemplateColumns = `repeat(${order.length},1fr)`;
    box.innerHTML = order.map((s, i) => {
      let cls = "";
      if (state.kind === "full" && state.stages[s] === false) cls = "skip";
      else if (status && status !== "running" && i <= idx) cls = "done";
      else if (i < idx) cls = "done";
      else if (i === idx) cls = s === "done" ? "done" : "active";
      const mark = cls === "done" ? "✓" : (i + 1);
      return `<div class="step ${cls}"><i>${mark}</i>${esc(T[state.lang].steps[s])}</div>`;
    }).join("");
    // Re-translate existing log lines on language switch
    document.querySelectorAll("#log div").forEach((d) => {
      if (d.dataset.ar) d.innerHTML = `<span>${esc(d.dataset.t)}</span>${esc(state.lang === "ar" ? d.dataset.ar : d.dataset.en)}`;
    });
  }

  // ------------------------------------------------------------------ results
  const color = (r) => r.verdict === "fraud" ? "var(--red)" : r.verdict === "suspicious" ? "var(--amber)" : r.verdict === "official" ? "#175cd3" : "var(--green)";
  const verdictText = (r) => state.lang === "ar" ? r.verdict_ar : r.verdict_en;
  const ring = (r) => `<div class="ring" style="--p:${Math.max(r.score, 2)};--c:${color(r)}"><b>${r.score}</b></div>`;
  const topReason = (r) => {
    const s = (r.signals || []).find((x) => !x.trust && x.weight > 0);
    if (s) return state.lang === "ar" ? s.ar : s.en;
    const tr = (r.signals || []).find((x) => x.trust);
    return tr ? (state.lang === "ar" ? tr.ar : tr.en) : "—";
  };
  const ageText = (r) => {
    const d = (r.evidence && r.evidence.domain) || {};
    if (d.age_days == null) return "—";
    return d.age_days >= 730 ? `${Math.floor(d.age_days / 365)} ${t("years")}` : `${d.age_days} ${t("days")}`;
  };

  function renderResults() {
    const all = state.results || [];
    const v = { fraud: 0, suspicious: 0, low: 0, official: 0 };
    all.forEach((r) => { v[r.verdict] = (v[r.verdict] || 0) + 1; });
    $("sTotal").textContent = all.length; $("sFraud").textContent = v.fraud;
    $("sSusp").textContent = v.suspicious; $("sLow").textContent = v.low + v.official;

    const q = state.q.toLowerCase();
    const rows = all.filter((r) => {
      if (state.filter !== "all") {
        if (state.filter === "low" ? !["low", "official"].includes(r.verdict) : r.verdict !== state.filter) return false;
      }
      if (q && !(`${r.url} ${r.host} ${topReason(r)}`.toLowerCase().includes(q))) return false;
      return true;
    });
    $("empty").classList.toggle("hidden", rows.length > 0);
    $("rows").innerHTML = rows.map((r) => {
      const isNew = !state.seen.has(r.url);
      state.seen.add(r.url);
      const srcs = (r.sources || []).map((s) => `<span class="src">${esc(T[state.lang].src[s] || s)}</span>`).join("");
      return `<tr data-url="${esc(r.url)}" class="${isNew ? "new" : ""}">
        <td><div class="score">${ring(r)}<span class="pill ${esc(r.verdict)}">${esc(verdictText(r))}</span></div></td>
        <td class="site"><b>${esc(r.host)}</b><small>${esc(r.url)}</small></td>
        <td>${srcs}</td>
        <td class="reason">${esc(topReason(r))}</td>
        <td>${esc(ageText(r))}</td></tr>`;
    }).join("");
  }

  function openDrawer(r) {
    const ev = r.evidence || {};
    const dom = ev.domain || {}; const tls = ev.tls || {}; const page = ev.page || {};
    const L = (o) => state.lang === "ar" ? o.ar : o.en;
    const risk = (r.signals || []).filter((s) => !s.trust && s.weight > 0);
    const trust = (r.signals || []).filter((s) => s.trust);
    const info = (r.signals || []).filter((s) => !s.trust && s.weight === 0);
    const sigRow = (s) => `<div class="sig ${s.trust ? "trust" : ""}"><div><span class="cat">${esc(s.category)}</span>${esc(L(s))}${s.detail ? `<small>${esc(s.detail)}</small>` : ""}</div><div class="w"><i style="width:${Math.round(s.weight * 100)}%"></i></div></div>`;
    const kv = [];
    const add = (k, val) => { if (val !== undefined && val !== null && val !== "") kv.push(`<dt>${esc(t(k))}</dt><dd>${val}</dd>`); };
    add("kvDomain", `<code>${esc(r.registered_domain)}</code>`);
    if (ev.final_url) add("kvFinal", `<code>${esc(defang(ev.final_url))}</code>`);
    add("kvIps", ev.ips && ev.ips.length ? `<code>${esc(ev.ips.join(", "))}</code>` : "");
    add("kvCreated", dom.created ? `${esc(dom.created.slice(0, 10))} (${esc(dom.age_days)} ${esc(t("days"))})` : "");
    add("kvRegistrar", esc(dom.registrar || ""));
    add("kvTls", tls.issuer ? esc(`${tls.issuer}${tls.cert_age_days != null ? ` · ${tls.cert_age_days} ${t("days")}` : ""}`) : (tls.error ? esc("✗ " + tls.error) : ""));
    add("kvStatus", esc(ev.http_status || ""));
    add("kvTitle", esc(page.title || ""));
    add("kvContext", esc((r.contexts || []).join(" · ")));
    add("kvSeen", esc((ev.first_seen || "").replace("T", " ").slice(0, 19)));
    if (ev.ml_probability != null) add("kvMl", `${Math.round(ev.ml_probability * 100)}%`);
    if (ev.virustotal) add("kvVt", esc(`malicious ${ev.virustotal.malicious} · suspicious ${ev.virustotal.suspicious}`));
    if (ev.ai_review) add("kvAi", esc(state.lang === "ar" ? ev.ai_review.reason_ar : ev.ai_review.reason_en));
    if (r.errors && r.errors.length) add("kvErrors", `<small>${esc(r.errors.join(" | "))}</small>`);

    $("drawer").innerHTML = `
      <button class="close" id="drawerClose" aria-label="close">×</button>
      <h3>${esc(r.host)}</h3><div class="muted ltr">${esc(defang(r.url))}</div>
      <div class="big">${ring(r)}<div><div class="pill ${esc(r.verdict)}">${esc(verdictText(r))}</div><div class="muted">${esc(t("score"))}: ${r.score}/100</div></div></div>
      <h4>${esc(t("reasons"))}</h4>${risk.map(sigRow).join("") || `<p class="muted">${esc(t("noReasons"))}</p>`}
      ${trust.length ? `<h4>${esc(t("trustNote"))}</h4>${trust.map(sigRow).join("")}` : ""}
      ${info.length ? info.map((s) => `<p class="muted">ℹ️ ${esc(L(s))}</p>`).join("") : ""}
      <h4>${esc(t("evidence"))}</h4><dl class="kv">${kv.join("")}</dl>
      <div class="actions">
        <button class="secondary" id="cpCase">${esc(t("copyCase"))}</button>
        <button class="ghost dark" id="cpUrl">${esc(t("copyUrl"))}</button>
        ${state.scanId ? `<button class="ghost dark" id="openRep">${esc(t("openReport"))}</button>` : ""}
      </div>`;
    $("drawer").classList.remove("hidden"); $("drawerBg").classList.remove("hidden");
    $("drawerClose").onclick = closeDrawer;
    $("cpUrl").onclick = () => copy(defang(r.url));
    $("cpCase").onclick = () => copy(caseSummary(r));
    if ($("openRep")) $("openRep").onclick = openReport;
  }

  function caseSummary(r) {
    const ev = r.evidence || {}; const dom = ev.domain || {};
    const ar = state.lang === "ar";
    const lines = [
      ar ? "بلاغ موقع مشبوه — رصد" : "Suspicious website case — Rasd",
      `URL: ${defang(r.url)}`,
      ev.final_url ? `Final URL: ${defang(ev.final_url)}` : "",
      `${ar ? "النطاق" : "Domain"}: ${r.registered_domain}`,
      `${ar ? "درجة الخطورة" : "Risk score"}: ${r.score}/100 (${verdictText(r)})`,
      ev.ips && ev.ips.length ? `IP: ${ev.ips.join(", ")}` : "",
      dom.created ? `${ar ? "تاريخ التسجيل" : "Registered"}: ${dom.created.slice(0, 10)} — ${dom.registrar || ""}` : "",
      `${ar ? "أول رصد" : "First seen"}: ${ev.first_seen || r.analyzed_at}`,
      ar ? "الأسباب:" : "Reasons:",
      ...(r.signals || []).filter((s) => !s.trust && s.weight > 0).map((s) => `- ${ar ? s.ar : s.en}`),
    ];
    return lines.filter(Boolean).join("\n");
  }

  function closeDrawer() { $("drawer").classList.add("hidden"); $("drawerBg").classList.add("hidden"); }
  function openReport() { if (state.scanId) window.open(`/api/report/${state.scanId}.html?lang=${state.lang}`, "_blank"); }

  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); } catch { /* ignore */ }
      ta.remove();
    }
    toast(t("copied"));
  }

  function toast(msg) {
    const d = document.createElement("div"); d.className = "toast"; d.textContent = msg;
    document.body.appendChild(d); setTimeout(() => d.remove(), 1800);
  }

  // ------------------------------------------------------------------ settings
  function openSettings() {
    const s = state.status.settings;
    [["k_serpapi", s.serpapi_key], ["k_gsb", s.gsb_key], ["k_vt", s.vt_key], ["k_ai", s.anthropic_key]].forEach(([id, set]) => {
      $(id).value = ""; $(id).placeholder = set ? t("keySet") : "";
    });
    $("k_model").value = s.anthropic_model || "";
    $("settingsModal").classList.remove("hidden");
  }

  async function saveSettings() {
    const val = (id) => $(id).value.trim() || "__keep__";
    const body = { serpapi_key: val("k_serpapi"), gsb_key: val("k_gsb"), vt_key: val("k_vt"),
                   anthropic_key: val("k_ai"), anthropic_model: $("k_model").value.trim() || "__keep__" };
    const s = await api("/api/settings", { method: "POST", body: JSON.stringify(body) });
    state.status.settings = s; renderIntegrations();
    $("settingsModal").classList.add("hidden"); toast(t("saved"));
  }

  // ------------------------------------------------------------------ wiring
  $("btnFull").onclick = () => start("full").catch((e) => toast(e.message));
  $("btnCheck").onclick = () => start("check").catch((e) => toast(e.message));
  $("btnStop").onclick = () => state.jobId && api(`/api/jobs/${state.jobId}/cancel`, { method: "POST" });
  $("btnLang").onclick = () => { state.lang = state.lang === "ar" ? "en" : "ar"; localStorageSet("rasd_lang", state.lang); applyLang(); };
  $("btnSettings").onclick = openSettings;
  $("btnCloseSettings").onclick = () => $("settingsModal").classList.add("hidden");
  $("btnSaveSettings").onclick = () => saveSettings().catch((e) => toast(e.message));
  $("btnReport").onclick = openReport;
  $("btnCsv").onclick = () => { if (state.scanId) window.location = `/api/report/${state.scanId}.csv`; };
  $("drawerBg").onclick = closeDrawer;
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeDrawer(); $("settingsModal").classList.add("hidden"); } });
  $("filter").oninput = (e) => { state.q = e.target.value; renderResults(); };
  $("tabs").onclick = (e) => {
    const b = e.target.closest("button"); if (!b) return;
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("active", x === b));
    state.filter = b.dataset.f; renderResults();
  };
  $("rows").onclick = (e) => {
    const tr = e.target.closest("tr"); if (!tr) return;
    const r = state.results.find((x) => x.url === tr.dataset.url); if (r) openDrawer(r);
  };
  $("history").onchange = async (e) => {
    const id = e.target.value; if (!id) return;
    clearTimeout(state.timer); state.jobId = null;
    state.scanId = id; state.results = await api(`/api/scans/${id}/results`);
    state.results.forEach((r) => state.seen.add(r.url));
    $("btnReport").disabled = false; $("btnCsv").disabled = false;
    renderResults();
  };

  loadStatus().then(applyLang).catch(() => applyLang());
})();
