#!/bin/bash
# Rasd launcher for macOS - double-click this file.
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  python3 app.py
else
  echo "Python 3.9+ is not installed. Opening https://www.python.org/downloads/ ..."
  open "https://www.python.org/downloads/"
  read -r -p "Press Enter to close"
fi
