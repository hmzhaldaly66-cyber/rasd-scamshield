# Rasd (رصد) — Technical Documentation

**ScamShield AI Hackathon — Abu Dhabi Police × 42 Abu Dhabi** · Team Falcon Eye (فريق عين الصقر), Abu Dhabi University

This document explains the **architecture**, the **model choices** and the **privacy and security design** of Rasd. Run instructions, trade-offs and future work are summarised in the [README](../README.md).

---

## 1. Purpose and scope

**Challenge:** detect fraudulent links and websites used in cybercrime and financial fraud across the open internet, including search-engine results and Maps, and identify them early.

**Rasd's answer:** a one-click pipeline that (1) discovers candidate sites from sources that see them early, (2) analyses each one with explainable indicators, (3) ranks them by a 0–100 risk score, and (4) produces evidence an analyst can act on. Rasd is a decision-support tool: **a human analyst makes the final decision.**

**In scope:** websites and links impersonating UAE government entities, banks, telecoms and delivery companies (configurable list of 18 protected brands).
**Out of scope for the MVP:** social-media posts and ads, messaging channels, mobile apps.

---

## 2. System architecture

### 2.1 Overview

```mermaid
flowchart TB
    UI["Bilingual dashboard<br/>(static/ — HTML/CSS/JS)"] -- "JSON API (localhost only)" --> SRV["server.py<br/>local HTTP server"]
    SRV --> PIPE["pipeline.py<br/>scan job (background thread)"]
    subgraph Discovery ["Discovery — sources.py"]
        CT["Certificate Transparency<br/>(crt.sh)"]
        TYPO["Look-alike domains<br/>+ DNS check"]
        SE["Search results & ads<br/>(SerpApi or DuckDuckGo/Bing)"]
        MAPS["Google Maps listings<br/>(SerpApi)"]
        MAN["Manual links / SMS text"]
    end
    PIPE --> Discovery
    Discovery --> DEDUP["Deduplicate by host<br/>+ prioritise + cap"]
    DEDUP --> GSB["Google Safe Browsing<br/>batch lookup (optional)"]
    GSB --> AN["analyzer.py — per URL, 10 in parallel"]
    subgraph Analysis ["Four analysis layers"]
        L1["URL layer<br/>features.py"]
        L2["Domain/network layer<br/>netcheck.py"]
        L3["Page content layer<br/>content.py"]
        L4["Intelligence & AI layer<br/>intel.py, scoring.py"]
    end
    AN --> Analysis --> SC["scoring.py<br/>noisy-OR score + verdict"]
    SC --> VT["VirusTotal for the 4 riskiest<br/>(optional)"]
    VT --> DB[("SQLite<br/>data/rasd.db")]
    DB --> REP["report.py<br/>HTML→PDF & CSV evidence"]
    SRV --> REP
```

### 2.2 Components

| Module | Responsibility |
|---|---|
| `app.py` | Entry point: loads config, finds a free port (8765 by default), starts the server, opens the browser. |
| `rasd/server.py` | Local HTTP server on `127.0.0.1` built on `http.server`. Serves the dashboard and a JSON API: start full scan / quick check, poll job, cancel, list scans, get results, reports, settings. |
| `rasd/pipeline.py` | Runs a scan as a background job with live progress and logs: discovery → deduplication → blocklist batch → parallel analysis → VirusTotal for the top results → save → summary. Supports cancellation. |
| `rasd/sources.py` | Discovery sources: Certificate Transparency, look-alike DNS sweep, search engines, Google Maps. |
| `rasd/features.py` | URL-only analysis: lexical features, brand impersonation (keyword, same name with another TLD, homoglyph, typosquat). Also the feature vector for the optional ML model. |
| `rasd/netcheck.py` | DNS resolution with timeouts, domain age via RDAP, TLS certificate inspection, page download. |
| `rasd/content.py` | Static HTML analysis: forms and fields, form targets, scripts, resources, redirects, brand mentions, scam language. |
| `rasd/analyzer.py` | Orchestrates the analysis of one URL, including the internal-network guard and redirect handling. |
| `rasd/intel.py` | Optional Google Safe Browsing, VirusTotal and Claude page review. |
| `rasd/scoring.py` | Score combination, verdict thresholds, optional logistic-regression model. |
| `rasd/storage.py` | SQLite storage of scans and results; "first seen" lookup per domain. |
| `rasd/report.py` | Printable HTML report (saved as PDF from the browser) and CSV export. |
| `rasd/util.py` | URL parsing, registered-domain extraction (built-in suffix list incl. `.gov.ae` and free-hosting platforms), safe HTTP client, URL extraction from free text (SMS). |
| `static/` | Dashboard: one-click scan, live log and progress, filters, details drawer, history, settings, Arabic/English toggle. |

### 2.3 Scan lifecycle

1. The analyst presses **Start full scan** (or **Check these links only**). Free text such as an SMS is reduced to the links it contains; the rest of the text is discarded.
2. `pipeline.py` creates a job and runs the enabled discovery stages, logging each step to the dashboard.
3. Candidates are deduplicated by host. The more specific source wins (manual > CT > look-alike > Maps > search ad > search), and all sources and contexts are kept as evidence.
4. Candidates are prioritised and capped (default 200).
5. If a Google Safe Browsing key is set, all URLs are checked in one batch.
6. Ten worker threads analyse URLs in parallel; results stream to the dashboard as they finish.
7. If a VirusTotal key is set, the 4 riskiest domains (score ≥ 40) are checked and re-scored.
8. Results are saved to SQLite with a "first seen" timestamp per domain; the summary (counts per verdict and source, duration) is stored with the scan.

### 2.4 Per-URL analysis

```
URL ─► URL layer (always, offline)
     └─ official domain? ──► score 0, verdict "official", stop
     ─► DNS resolve ── internal/private IP? ──► flag, do NOT fetch
     ─► download page (no JavaScript, ≤ 2 MB, ≤ 10 s, redirects tracked)
          └─ redirected to another domain? ► analyse the final URL too
             (redirect to an official site = trust signal)
     ─► page content layer (HTML parsing)
     ─► TLS certificate + domain age (RDAP)   [skipped for allowlisted/official]
     ─► Safe Browsing result (from batch)
     ─► optional ML probability
     ─► score; if ≥ 25 and a Claude key is set ► AI review ► re-score
```

---

## 3. Detection approach and model choices

### 3.1 Discovery sources

| Source | How it works | Why it matters |
|---|---|---|
| **Certificate Transparency** | Queries crt.sh for certificates issued in the last 30 days whose names contain a protected keyword; keeps names that pass the brand-impersonation check and are not official or allowlisted (≤ 40 per keyword). | Every HTTPS site needs a publicly logged certificate, often before the scam campaign starts. |
| **Look-alike domains** | For each official domain: same name on 15 other TLDs, name + common words (`-pay`, `-fines`, `-gov`, `-uae` …), and for names of 5+ letters: homoglyphs, omissions, repetitions, transpositions, keyboard slips and hyphenation (≤ 60 per brand). Each candidate is resolved in DNS; resolvers that answer for non-existent domains are detected and filtered out. | Finds registered look-alikes even before they appear anywhere. |
| **Search engines & ads** | 7 configurable queries (Arabic and English). With SerpApi: Google organic results and ads (`gl=ae`). Without it: DuckDuckGo HTML, then Bing HTML. Paid ads get an extra discovery signal. | Abu Dhabi Police has warned specifically about fake links and ads in search results. |
| **Google Maps** | 3 configurable queries around Abu Dhabi via SerpApi; collects listings with websites; flags listings whose title uses a protected name while linking to an unofficial site. | The challenge explicitly includes Maps. |
| **Manual / SMS** | Links extracted from pasted text (including bare domains, excluding e-mail addresses). | Lets analysts check reports from the public instantly. |

### 3.2 Indicators

Each indicator has a **weight** between 0 and 1 and a reason in Arabic and English. Main indicators:

| Layer | Indicator | Weight |
|---|---|---|
| URL | Look-alike spelling of an official domain (typosquat / homoglyph) | 0.60 |
| URL | Contains a protected brand name but is not the official site | 0.50 |
| URL | Same name as the brand with a different extension | 0.50 |
| URL | Pretends to be governmental but is not under `.gov.ae` | 0.35 |
| URL | Raw IP address / Punycode / `@` in URL | 0.35 / 0.35 / 0.30 |
| URL | URL shortener / free hosting platform | 0.20 / 0.20 |
| URL | Sensitive words (`login`, `pay`, `fine`, `otp` …) | 0.08–0.20 |
| URL | Cheap TLD, many sub-domains, many hyphens, odd port | 0.15 each |
| Domain | Registered < 30 days / < 90 days / < 1 year ago | 0.45 / 0.25 / 0.08 |
| Domain | Invalid TLS certificate / certificate < 7 days old | 0.25 / 0.10 |
| Domain | Redirects to another domain | 0.15 |
| Content | Sends data to a Telegram bot | 0.50 |
| Content | Uses a protected brand's name **and** asks for sensitive data | 0.50 |
| Content | Asks for card number / CVV / expiry | 0.35 |
| Content | Loads logos/assets from the official site while not being it | 0.35 |
| Content | Form submits to another domain | 0.25 |
| Content | Scam/urgency language (Arabic & English) | 0.12–0.25 |
| Content | OTP field / password field / Emirates ID or passport field | 0.20 / 0.12 / 0.12 |
| Discovery | Maps listing impersonating a brand / paid search ad / new CT certificate / live look-alike | 0.50 / 0.15 / 0.15 / 0.20 |
| Intel | Google Safe Browsing match / ≥ 2 VirusTotal engines | 0.90 / 0.80 |
| AI | Claude review says scam | 0.6 × confidence |
| AI | ML model probability p ≥ 0.6 | min(0.5, p − 0.5) |
| **Trust** | Official domain of a protected brand | score forced to 0 |
| **Trust** | Allowlisted domain / redirect to official site / domain older than 5 years | −0.70 / −0.60 / −0.30 |

The full list (57 indicators) is in `features.py`, `netcheck.py`, `content.py`, `analyzer.py`, `sources.py`, `intel.py` and `scoring.py`.

### 3.3 Scoring model

Risk indicators are combined with a **noisy-OR**, then trust indicators reduce the result:

```
risk  = 1 − Π (1 − wᵢ)            over risk indicators
risk ← risk × Π (1 − tⱼ)          over trust indicators (not applied when Safe Browsing or VirusTotal confirm)
score = round(100 × risk)
```

| Score | Verdict |
|---|---|
| 70–100 | Likely fraud |
| 40–69 | Suspicious — needs review |
| 0–39 | Low risk |
| — | Official (known official domain) |

**Worked example.** A site containing "adpolice", registered 3 days ago, asking for card details and sending them to a Telegram bot:
`1 − (1−0.50)(1−0.45)(1−0.35)(1−0.50) = 1 − 0.089 = 0.91` → **91, likely fraud**.
A news article on an allowlisted site that mentions Abu Dhabi Police in its title and "fines" in its URL:
`(1 − (1−0.15)(1−0.20)) × (1−0.70) = 0.32 × 0.30 ≈ 0.10` → **10, low risk**.

**Why this model.**
- **Explainability:** every point of the score maps to a reason and evidence the analyst can verify. This matters for law-enforcement decisions.
- **No labelled local data:** a supervised model needs confirmed UAE cases we did not have; weighted indicators encode expert knowledge of phishing kits instead.
- **Robust combination:** noisy-OR saturates towards 100 as independent evidence accumulates, and no single weak indicator can produce a high score.
- **Limitation:** the weights were set by the team and still need calibration on confirmed cases (see §5.3).

### 3.4 Optional machine-learning model

- **Model:** logistic regression on 20 numeric URL features (lengths, counts of dots, hyphens and digits, sub-domain depth, IP/Punycode/`@`, HTTPS, cheap TLD, shortener, sensitive words, path depth, query parameters, entropy of the domain label, odd port, free hosting, special characters).
- **Why logistic regression:** interpretable coefficients, fast, and its inference is a dot product, so the app runs it in pure Python with no NumPy or scikit-learn at runtime.
- **Training:** `tools/train_model.py` (needs pandas and scikit-learn) trains on any labelled URL dataset (e.g. the public PhiUSIIL phishing URL dataset), prints a test-set report and ROC-AUC, and saves standardisation parameters and coefficients to `model_weights.json`.
- **Status:** no trained model is shipped in the repository, because we could not validate one on UAE data. Without `model_weights.json` the ML indicator is simply absent.

### 3.5 Optional AI page review (Claude)

- **When:** only if an Anthropic key is configured, only for pages that were downloaded, and only when the score is already ≥ 25. This limits cost and the amount of data sent out.
- **Input:** the URL, page title (≤ 200 characters), a summary of the forms, and up to 3,500 characters of visible page text. Default model: `claude-haiku-5-5` (configurable).
- **Output:** strict JSON: `is_scam`, `confidence`, `impersonated_brand`, and a one-sentence reason in Arabic and in English, which is shown to the analyst.
- **Safeguards:** page content comes from untrusted sites, so it is passed only as data inside the prompt, the answer is parsed as JSON, and its weight is capped at 0.6 × confidence. It can never decide a verdict alone.

---

## 4. Privacy and security design

### 4.1 Principles
1. **Local first:** all processing and storage happen on the analyst's computer. There is no cloud backend and no telemetry.
2. **Minimum data out:** external services receive only what they need (§4.3). Optional services are off until a key is added.
3. **Treat every analysed site as hostile:** never execute its code, never submit data to it, never let it reach the internal network.
4. **Human in the loop:** scores are evidence for an analyst, not automatic actions.

### 4.2 Data stored locally

| Data | Where | Notes |
|---|---|---|
| Scan summaries and results (URL, host, score, indicators, IPs, RDAP data, TLS issuer, page title, ≤ 400-character text sample, first-seen time) | `data/rasd.db` (SQLite) | About public websites only. Excluded from git. Delete the `data/` folder to erase history. |
| API keys | `settings.local.json` | Never displayed back in the dashboard (it only shows whether a key is set). Excluded from git. |
| Pasted SMS text | **not stored** | Only the extracted links are kept; phone numbers, names and the message text are discarded after link extraction. |
| Optional ML weights | `model_weights.json` | Model parameters only. |

### 4.3 What leaves the machine

| Destination | What is sent | When |
|---|---|---|
| crt.sh | Protected-brand keywords | Full scan, CT stage |
| System DNS resolver | Candidate host names | Look-alike stage and every analysed URL |
| rdap.org → registry RDAP | Registered domain name | Analysed non-official, non-allowlisted domains |
| The analysed website | One HTTP GET (browser-like User-Agent) and a TLS handshake | Every analysed URL |
| DuckDuckGo / Bing | Search queries from `config.json` | Search stage without SerpApi |
| SerpApi | Search and Maps queries + key | Only if the key is set |
| Google Safe Browsing | List of candidate URLs | Only if the key is set |
| VirusTotal | Up to 4 registered domain names per scan | Only if the key is set |
| Anthropic | URL, title, form summary, ≤ 3,500 chars of page text | Only if the key is set and the score is ≥ 25 |
| Google Fonts | Font request when the dashboard loads | UI only; system fonts are used offline |

No personal data about citizens or victims is sent to any service.

### 4.4 Safe analysis of hostile content
- **No code execution:** pages are fetched as raw HTML with `urllib` and parsed with `html.parser`; JavaScript never runs and no browser engine is used.
- **No interaction:** forms are analysed, never filled or submitted.
- **Resource limits:** pages are capped at 2 MB with 10-second timeouts; DNS lookups have hard timeouts; at most 8 redirects are followed.
- **Internal-network guard (SSRF protection, in `analyzer.py`):** if a host resolves to a private, loopback, link-local, reserved, multicast or unspecified address, it is flagged and never fetched.
- **TLS:** certificates are verified. If verification fails, the page is re-fetched read-only without verification so the evidence can still be collected, and the failure itself is recorded as an indicator.

### 4.5 Local server hardening
- Binds to `127.0.0.1` only, so it is not reachable from the network.
- POST requests carrying an `Origin` header from another site are rejected (protection against cross-site requests from web pages).
- Static file paths are resolved and confined to `static/` (path-traversal protection).
- All text that comes from analysed sites (titles, URLs, reasons) is HTML-escaped in the dashboard and in reports; responses send `X-Content-Type-Options: nosniff` and `Cache-Control: no-store`.

### 4.6 Evidence handling
- Links in reports are **defanged** (`hxxps://evil[.]com`) to prevent accidental clicks when reports are shared.
- Each result records sources, discovery context, IPs, registrar, registration date, certificate issuer, final URL after redirects and the first time Rasd saw the domain.
- CSV export includes a UTF-8 BOM so Arabic opens correctly in Excel.

### 4.7 Known limitations
- API keys are stored in plain text on the local disk (protected only by the operating system account).
- Analysed websites can see the analyst's public IP address. For operational use, page fetching should go through a dedicated egress proxy or VPN.
- There is no user authentication: the tool is designed for one analyst on one machine.

---

## 5. Evaluation

### 5.1 Automated tests
`python -m unittest discover -s tests -v` — 23 tests, all passing:
- URL features: official domains, brand keywords, typosquats, homoglyphs, same-name-other-TLD, government mimicry, allowlist, no false positive on `tammy-shop.com`, SMS link extraction.
- Look-alike generation, page-content analysis (phishing page vs news page).
- End-to-end analysis with simulated network responses (live phishing site → "likely fraud"; old news site → "low"; internal IP never fetched).
- Scoring maths, deduplication priority, report escaping and defanging, ML weights loading.
- Web server: dashboard, status, quick-check flow, HTML/CSV reports, cross-origin POST blocked, path traversal blocked.

### 5.2 Live run (22 November 2026, SerpApi enabled)
226 links discovered; 200 analysed in depth; 23 "likely fraud", 108 "suspicious", 69 "low risk / official"; total 297 seconds.

### 5.3 Observed false-positive pattern
The highest-scoring results included domains that carry a protected brand name with a different extension. Some of these can be **defensive registrations owned by the brand itself**, or parked domains. They are correctly surfaced for review, but should not be acted on without verification (registrant, redirect target, page content). Adding parked-page and defensive-registration detection is the first planned improvement.

---

## 6. Configuration reference (`config.json`)

| Key | Meaning | Default |
|---|---|---|
| `brands[]` | Protected entities: names (AR/EN), official domains, URL keywords, names to look for in page content, CT keywords, keyword exceptions | 18 entities |
| `search_queries[]` / `maps_queries[]` | Discovery queries | 7 / 3 |
| `maps_location` | Map centre for Maps queries | Abu Dhabi |
| `allowlist_domains[]` | Trusted sites (news, platforms, `gov.ae` …) | 43 |
| `scan.ct_days` / `ct_max_per_keyword` | CT look-back window / results per keyword | 30 / 40 |
| `scan.typosquat_max_per_brand` | Look-alike candidates per brand | 60 |
| `scan.max_urls_to_analyze` | Analysis cap per scan | 200 |
| `scan.workers` | Parallel analysis threads | 10 |
| `scan.fetch_timeout_seconds` / `max_page_bytes` | Page download limits | 10 / 2,000,000 |
| `scan.vt_max_lookups` | VirusTotal lookups per scan | 4 |

---

## 7. Roadmap

1. Calibrate weights on confirmed Abu Dhabi Police cases; train a gradient-boosted model with per-feature explanations.
2. Detect parked domains and defensive registrations to cut false positives.
3. Sandboxed headless rendering with screenshots and perceptual-hash comparison against official sites.
4. Real-time CT monitoring (CertStream) and scheduled scans.
5. Multi-user deployment with authentication, audit log and case management.
6. Automatic takedown requests to registrars and hosting providers; public reporting channels (WhatsApp bot, browser extension).
