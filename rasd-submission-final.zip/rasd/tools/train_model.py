#!/usr/bin/env python3
"""Optional: train the machine-learning layer of Rasd on a labelled URL dataset.

The dashboard works without this. Training adds a logistic-regression model over Rasd's own URL
features; the weights are saved to model_weights.json and used by the app with no extra packages.

Requirements (only for training):   pip install pandas scikit-learn

Example with the public PhiUSIIL phishing URL dataset (UCI Machine Learning Repository):
    python tools/train_model.py PhiUSIIL_Phishing_URL_Dataset.csv --url-col URL --label-col label --phishing-value 0

Any CSV works as long as it has a URL column and a label column. ALWAYS check the printed samples to
confirm which label value means "phishing" in your dataset, and set --phishing-value accordingly.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from rasd.features import ml_vector  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("csv", help="CSV file with URLs and labels")
    ap.add_argument("--url-col", default="URL")
    ap.add_argument("--label-col", default="label")
    ap.add_argument("--phishing-value", default="0", help="label value that means phishing (string compare)")
    ap.add_argument("--max-rows", type=int, default=300_000)
    ap.add_argument("--out", default=os.path.join(ROOT, "model_weights.json"))
    args = ap.parse_args()

    try:
        import pandas as pd
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import classification_report, roc_auc_score
        from sklearn.model_selection import train_test_split
    except ImportError:
        sys.exit("Training needs extra packages:  pip install pandas scikit-learn")

    df = pd.read_csv(args.csv, usecols=[args.url_col, args.label_col]).dropna()
    if len(df) > args.max_rows:
        df = df.sample(args.max_rows, random_state=42)
    df["y"] = (df[args.label_col].astype(str) == str(args.phishing_value)).astype(int)

    print(f"Rows: {len(df):,}   phishing: {df['y'].sum():,}   legitimate: {(1 - df['y']).sum():,}")
    print("\nSample rows labelled PHISHING (check these look malicious!):")
    for u in df[df.y == 1][args.url_col].head(5):
        print("   ", u)
    print("Sample rows labelled LEGITIMATE:")
    for u in df[df.y == 0][args.url_col].head(5):
        print("   ", u)
    if df["y"].nunique() < 2:
        sys.exit("\nOnly one class found. Check --label-col / --phishing-value.")

    urls = df[args.url_col].astype(str).tolist()
    urls = [u if "://" in u else "http://" + u for u in urls]
    X = pd.DataFrame([ml_vector(u) for u in urls])
    y = df["y"].values
    mean, std = X.mean(), X.std().replace(0, 1.0)
    Xs = (X - mean) / std

    X_tr, X_te, y_tr, y_te = train_test_split(Xs, y, test_size=0.2, random_state=42, stratify=y)
    clf = LogisticRegression(max_iter=2000, class_weight="balanced")
    clf.fit(X_tr, y_tr)
    proba = clf.predict_proba(X_te)[:, 1]
    print("\nTest-set results:")
    print(classification_report(y_te, (proba >= 0.5).astype(int), target_names=["legitimate", "phishing"], digits=3))
    print(f"ROC-AUC: {roc_auc_score(y_te, proba):.3f}")

    model = {
        "type": "logistic_regression",
        "features": list(X.columns),
        "coefficients": {c: float(w) for c, w in zip(X.columns, clf.coef_[0])},
        "intercept": float(clf.intercept_[0]),
        "mean": {c: float(mean[c]) for c in X.columns},
        "std": {c: float(std[c]) for c in X.columns},
        "trained_on": os.path.basename(args.csv),
        "rows": int(len(df)),
    }
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(model, fh, indent=2)
    print(f"\nSaved model to {args.out}. Restart Rasd to use it.")
    print("Most influential features:")
    for c, w in sorted(model["coefficients"].items(), key=lambda kv: -abs(kv[1]))[:8]:
        print(f"   {c:22s} {w:+.3f}")


if __name__ == "__main__":
    main()
