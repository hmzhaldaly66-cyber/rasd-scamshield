#!/usr/bin/env python3
"""Rasd (رصد) - start the dashboard. Double-click a START_* launcher or run:  python app.py"""
from __future__ import annotations

import argparse
import sys
import threading
import webbrowser

if sys.version_info < (3, 9):
    sys.exit("Rasd needs Python 3.9 or newer. Download it from https://www.python.org/downloads/")

from rasd import __version__  # noqa: E402
from rasd.config import load_config  # noqa: E402
from rasd.server import make_server  # noqa: E402


def main() -> None:
    cfg = load_config().get("server", {})
    ap = argparse.ArgumentParser(description="Rasd - fraudulent website detection dashboard")
    ap.add_argument("--host", default=cfg.get("host", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=cfg.get("port", 8765))
    ap.add_argument("--no-browser", action="store_true", help="do not open the browser automatically")
    args = ap.parse_args()

    server = None
    for port in range(args.port, args.port + 20):
        try:
            server = make_server(args.host, port)
            break
        except OSError:
            continue
    if server is None:
        sys.exit("No free port found.")

    url = f"http://{args.host}:{server.server_address[1]}/"
    print("=" * 60)
    print(f"  Rasd v{__version__}  -  رصد")
    print(f"  Dashboard: {url}")
    print("  Keep this window open. Press Ctrl+C to stop.")
    print("=" * 60)
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
