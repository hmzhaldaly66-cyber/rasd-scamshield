#!/usr/bin/env bash
# Rasd launcher for Linux:  ./start_linux.sh
cd "$(dirname "$0")"
exec python3 app.py "$@"
