@echo off
chcp 65001 >nul
title Rasd - ScamShield AI
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo.
  echo  [!] Python 3.9+ is not installed.
  echo      Download it from https://www.python.org/downloads/
  echo      IMPORTANT: tick "Add python.exe to PATH" during installation.
  echo.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)
%PY% app.py
if errorlevel 1 pause
