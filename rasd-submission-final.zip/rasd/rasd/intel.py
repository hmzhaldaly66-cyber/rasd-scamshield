"""Optional external intelligence: Google Safe Browsing, VirusTotal and an AI (Claude) page review.

Each one only runs if its API key is set in the Settings panel. The core engine works without them.
"""
from __future__ import annotations

import json
import re
import urllib.parse

from .signals import sig
from .util import get_json


def safe_browsing_lookup(urls: list[str], api_key: str) -> tuple[dict[str, list[str]], str | None]:
    """Batch lookup. Returns ({url: [threat types]}, error)."""
    if not api_key or not urls:
        return {}, None
    hits: dict[str, list[str]] = {}
    endpoint = "https://safebrowsing.googleapis.com/v4/threatMatches:find?key=" + urllib.parse.quote(api_key)
    for i in range(0, len(urls), 450):
        chunk = urls[i:i + 450]
        payload = {
            "client": {"clientId": "rasd-scamshield", "clientVersion": "1.0"},
            "threatInfo": {
                "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE",
                                "POTENTIALLY_HARMFUL_APPLICATION"],
                "platformTypes": ["ANY_PLATFORM"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [{"url": u} for u in chunk],
            },
        }
        data, err = get_json(endpoint, data=payload, timeout=20)
        if err:
            return hits, err
        for m in (data or {}).get("matches", []) or []:
            u = m.get("threat", {}).get("url")
            if u:
                hits.setdefault(u, []).append(m.get("threatType", "THREAT"))
    return hits, None


def safe_browsing_signal(threats: list[str]) -> dict:
    t = ", ".join(sorted(set(threats)))
    return sig("gsb_match", 0.9, f"مُدرج في قائمة Google Safe Browsing كموقع ضار ({t})",
               f"Listed by Google Safe Browsing as dangerous ({t})", "intel")


def virustotal_domain(domain: str, api_key: str) -> tuple[dict | None, str | None]:
    if not api_key:
        return None, None
    data, err = get_json(f"https://www.virustotal.com/api/v3/domains/{urllib.parse.quote(domain)}",
                         headers={"x-apikey": api_key}, timeout=20)
    if err:
        return None, err
    stats = (((data or {}).get("data") or {}).get("attributes") or {}).get("last_analysis_stats") or {}
    return {"malicious": stats.get("malicious", 0), "suspicious": stats.get("suspicious", 0),
            "harmless": stats.get("harmless", 0)}, None


def virustotal_signals(stats: dict) -> list[dict]:
    mal = stats.get("malicious", 0)
    if mal >= 2:
        return [sig("vt_malicious", 0.8, f"{mal} من محركات VirusTotal صنّفت النطاق ضاراً",
                    f"{mal} VirusTotal engines flag this domain as malicious", "intel")]
    if mal == 1 or stats.get("suspicious", 0) >= 2:
        return [sig("vt_suspicious", 0.35, "بعض محركات VirusTotal تشتبه في النطاق",
                    "Some VirusTotal engines flag this domain as suspicious", "intel")]
    return []


LLM_PROMPT = """You are a fraud analyst for the UAE police. Decide if this web page is a scam/phishing page
(e.g. fake government fine payment, fake bank login, fake parcel delivery fee, fake prize).
Answer ONLY with a JSON object: {{"is_scam": true|false, "confidence": 0.0-1.0,
"impersonated_brand": "name or empty", "reason_ar": "one short Arabic sentence", "reason_en": "one short English sentence"}}

URL: {url}
Page title: {title}
Forms: {forms}
Visible text (truncated):
{text}
"""


def llm_review(url: str, title: str, text: str, forms_summary: str, api_key: str,
               model: str = "claude-haiku-5-5") -> tuple[dict | None, str | None]:
    """Ask Claude to judge the page. Page content is passed as data inside the prompt."""
    if not api_key:
        return None, None
    prompt = LLM_PROMPT.format(url=url, title=title[:200], forms=forms_summary[:300], text=text[:3500])
    payload = {"model": model or "claude-haiku-5-5", "max_tokens": 300,
               "messages": [{"role": "user", "content": prompt}]}
    data, err = get_json("https://api.anthropic.com/v1/messages", data=payload, timeout=40,
                         headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"})
    if err:
        return None, err
    try:
        out = "".join(block.get("text", "") for block in (data or {}).get("content", []))
        m = re.search(r"\{.*\}", out, re.S)
        return json.loads(m.group(0)) if m else None, None if m else "No JSON in AI reply"
    except Exception as exc:  # noqa: BLE001
        return None, f"AI parse error: {exc}"


def llm_signal(review: dict) -> list[dict]:
    if not review or not review.get("is_scam"):
        return []
    conf = float(review.get("confidence", 0.5) or 0.5)
    return [sig("ai_verdict", 0.6 * conf,
                f"تحليل الذكاء الاصطناعي: {review.get('reason_ar', 'الصفحة تبدو احتيالية')} (ثقة {int(conf * 100)}%)",
                f"AI review: {review.get('reason_en', 'Page looks fraudulent')} (confidence {int(conf * 100)}%)",
                "ai")]
