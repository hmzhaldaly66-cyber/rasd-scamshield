"""Discovery sources: where new suspicious links come from.

1. Certificate Transparency logs (crt.sh)  - new HTTPS sites whose names contain a protected brand.
2. Typosquat sweep                         - look-alike domains of official sites that are live in DNS.
3. Search engines                          - results and ads for queries scammers target.
4. Google Maps (SerpAPI key)               - business listings that link to unofficial websites.
"""
from __future__ import annotations

import concurrent.futures as cf
import datetime as dt
import html as htmlmod
import random
import re
import string
import urllib.parse

from . import netcheck
from .features import brand_matches, is_allowlisted, official_for_any_brand
from .signals import sig
from .util import get_json, http_request, decode_body, hostname, main_label, registered_domain


def _candidate(url: str, source: str, context: str = "", extra_signals=None) -> dict:
    return {"url": url, "source": source, "context": context, "extra_signals": extra_signals or []}


# --------------------------------------------------------------------------- 1. CT logs

def ct_search(keyword: str, config: dict, days: int = 30, limit: int = 40) -> tuple[list[dict], str | None]:
    q = urllib.parse.quote(f"%{keyword}%")
    data, err = get_json(f"https://crt.sh/?q={q}&output=json&exclude=expired", timeout=60)
    if err:
        return [], err
    cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)
    seen: dict[str, str] = {}
    for row in data or []:
        nb = row.get("not_before") or row.get("entry_timestamp") or ""
        try:
            when = dt.datetime.fromisoformat(nb.replace("Z", "")[:19]).replace(tzinfo=dt.timezone.utc)
        except ValueError:
            continue
        if when < cutoff:
            continue
        for name in (row.get("name_value") or "").split("\n"):
            name = name.strip().lower().lstrip("*.").rstrip(".")
            if not name or "." not in name or " " in name or name in seen:
                continue
            if official_for_any_brand(name, config) or is_allowlisted(name, config):
                continue
            if not brand_matches(name, config):
                continue
            seen[name] = when.date().isoformat()
    ordered = sorted(seen.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    out = []
    for name, date in ordered:
        out.append(_candidate(
            f"https://{name}/", "ct", f"cert {date}",
            [sig("ct_new_cert", 0.15, f"اكتُشف عبر سجلات الشهادات: شهادة جديدة صدرت بتاريخ {date}",
                 f"Discovered in Certificate Transparency logs: new certificate issued {date}", "discovery")]))
    return out, None


# --------------------------------------------------------------------------- 2. Typosquat sweep

QWERTY = {
    "q": "wa", "w": "qes", "e": "wrd", "r": "etf", "t": "ryg", "y": "tuh", "u": "yij", "i": "uok",
    "o": "ipl", "p": "ol", "a": "qsz", "s": "adwx", "d": "sfec", "f": "dgrv", "g": "fhtb",
    "h": "gjyn", "j": "hkum", "k": "jli", "l": "kop", "z": "asx", "x": "zsc", "c": "xdv",
    "v": "cfb", "b": "vgn", "n": "bhm", "m": "nj",
}
LOOKALIKE = {"o": ["0"], "l": ["1", "i"], "i": ["1", "l"], "e": ["3"], "a": ["4"], "s": ["5"],
             "m": ["rn"], "w": ["vv"], "d": ["cl"], "g": ["q"]}
COMBO = ["pay", "fines", "gov", "uae", "ae", "online", "portal", "services", "eservices", "login", "secure", "app"]
SWAP_TLDS = ["com", "net", "org", "info", "online", "site", "xyz", "top", "co", "ae", "me", "app", "live", "shop", "cc"]


def typosquat_candidates(official_domain: str, limit: int = 60) -> list[str]:
    reg = registered_domain(official_domain)
    sld = main_label(reg)
    out: list[str] = []

    def add(d: str):
        if d != reg and d not in out and re.fullmatch(r"[a-z0-9\-]+\.[a-z.]+", d) and not d.startswith("-"):
            out.append(d)

    for tld in SWAP_TLDS:
        add(f"{sld}.{tld}")
    for w in COMBO:
        for tld in ("com", "online", "net"):
            add(f"{sld}-{w}.{tld}")
        add(f"{w}-{sld}.com")
        add(f"{sld}{w}.com")
    if len(sld) >= 5:
        variants: list[str] = []
        for i, ch in enumerate(sld):
            for rep in LOOKALIKE.get(ch, []):
                variants.append(sld[:i] + rep + sld[i + 1:])
        for i in range(len(sld)):
            variants.append(sld[:i] + sld[i + 1:])               # omission
            variants.append(sld[:i] + sld[i] + sld[i:])           # repetition
            if i < len(sld) - 1:
                variants.append(sld[:i] + sld[i + 1] + sld[i] + sld[i + 2:])  # transposition
            for k in QWERTY.get(sld[i], "")[:2]:
                variants.append(sld[:i] + k + sld[i + 1:])        # keyboard slip
        for i in range(2, len(sld) - 1):
            variants.append(sld[:i] + "-" + sld[i:])              # hyphenation
        for v in variants:
            add(f"{v}.com")
    return out[:limit]


def typosquat_sweep(config: dict, per_brand: int = 60, log=None) -> list[dict]:
    """Return look-alike domains that actually exist (resolve in DNS)."""
    # Make sure DNS works at all, otherwise every lookup would just time out.
    if not (netcheck.resolve("example.com", timeout=4) or netcheck.resolve("google.com", timeout=4)):
        if log:
            log("تخطّي فحص النطاقات المشابهة: لا يوجد اتصال DNS بالإنترنت",
                "Skipping look-alike sweep: DNS / internet not reachable")
        return []
    # Detect DNS resolvers that answer for non-existent domains (would make everything "live").
    junk = "".join(random.choice(string.ascii_lowercase) for _ in range(18)) + ".com"
    wildcard_ips = set(netcheck.resolve(junk, timeout=3))
    pairs = []
    for brand in config.get("brands", []):
        for od in brand.get("official_domains", [])[:1]:
            for cand in typosquat_candidates(od, per_brand):
                if not official_for_any_brand(cand, config) and not is_allowlisted(cand, config):
                    pairs.append((brand, od, cand))
    live = []
    with cf.ThreadPoolExecutor(max_workers=32) as pool:
        futs = {pool.submit(netcheck.resolve, cand, 2.5): (b, od, cand) for b, od, cand in pairs}
        for fut in cf.as_completed(futs):
            b, od, cand = futs[fut]
            ips = fut.result()
            if ips and not (set(ips) & wildcard_ips):
                live.append(_candidate(
                    f"https://{cand}/", "typosquat", f"look-alike of {od}",
                    [sig("typosquat_live", 0.2, f"نطاق مشابه لـ {od} ومُفعَّل فعلياً على الإنترنت",
                         f"Look-alike of {od} that is live on the internet", "discovery")]))
    if log:
        log(f"فُحص {len(pairs)} نطاقاً مشابهاً، منها {len(live)} نطاقاً فعّالاً",
            f"Checked {len(pairs)} look-alike domains, {len(live)} are live")
    return live


# --------------------------------------------------------------------------- 3. Search engines

def _ddg_search(query: str, limit: int) -> tuple[list[tuple[str, bool]], str | None]:
    res = http_request("https://html.duckduckgo.com/html/?" + urllib.parse.urlencode({"q": query, "kl": "xa-ar"}),
                       timeout=20)
    if res["error"] and not res["body"]:
        return [], res["error"]
    page = decode_body(res["body"], res["headers"])
    out: list[tuple[str, bool]] = []
    for m in re.finditer(r'<a[^>]+class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"', page):
        href = htmlmod.unescape(m.group(1))
        if href.startswith("//"):
            href = "https:" + href
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(href).query)
        is_ad = "/y.js" in href
        if "uddg" in q:
            link = q["uddg"][0]
        elif is_ad and "ad_domain" in q:
            link = "https://" + q["ad_domain"][0] + "/"
        elif href.startswith("http") and "duckduckgo.com" not in href:
            link = href
        else:
            continue
        out.append((link, is_ad))
        if len(out) >= limit:
            break
    return out, None


def _bing_search(query: str, limit: int) -> tuple[list[tuple[str, bool]], str | None]:
    res = http_request("https://www.bing.com/search?" + urllib.parse.urlencode({"q": query, "cc": "AE"}), timeout=20)
    if res["error"] and not res["body"]:
        return [], res["error"]
    page = decode_body(res["body"], res["headers"])
    out = []
    for m in re.finditer(r'<li class="b_algo"[^>]*>.*?<a[^>]+href="(https?://[^"]+)"', page, re.S):
        out.append((htmlmod.unescape(m.group(1)), False))
        if len(out) >= limit:
            break
    return out, None


def _serpapi_google(query: str, key: str, limit: int) -> tuple[list[tuple[str, bool]], str | None]:
    params = {"engine": "google", "q": query, "gl": "ae", "hl": "ar", "num": limit, "api_key": key}
    data, err = get_json("https://serpapi.com/search.json?" + urllib.parse.urlencode(params), timeout=40)
    if err:
        return [], err
    out = [(a.get("link"), True) for a in (data or {}).get("ads", []) if a.get("link")]
    out += [(r.get("link"), False) for r in (data or {}).get("organic_results", []) if r.get("link")]
    return out[: limit + 5], None


def search_scan(config: dict, settings: dict, log=None) -> list[dict]:
    limit = config.get("scan", {}).get("search_max_results_per_query", 10)
    key = settings.get("serpapi_key")
    out = []
    for query in config.get("search_queries", []):
        if key:
            links, err = _serpapi_google(query, key, limit)
            engine = "Google"
        else:
            links, err = _ddg_search(query, limit)
            engine = "DuckDuckGo"
            if not links:
                links, err2 = _bing_search(query, limit)
                engine = "Bing"
                err = err or err2
        if log:
            if links:
                log(f"بحث «{query}» عبر {engine}: {len(links)} نتيجة", f"Search '{query}' via {engine}: {len(links)} results")
            else:
                log(f"تعذّر البحث «{query}»: {err or 'لا نتائج'}", f"Search '{query}' failed: {err or 'no results'}")
        for link, is_ad in links:
            extra = []
            if is_ad:
                extra.append(sig("search_ad", 0.15, f"إعلان مدفوع يظهر عند البحث عن «{query}»",
                                 f"Paid ad shown for the search '{query}'", "discovery"))
            out.append(_candidate(link, "search_ad" if is_ad else "search", query, extra))
    return out


# --------------------------------------------------------------------------- 4. Google Maps

def maps_scan(config: dict, settings: dict, log=None) -> list[dict]:
    key = settings.get("serpapi_key")
    if not key:
        if log:
            log("تخطّي فحص الخرائط: يحتاج مفتاح SerpAPI (من الإعدادات)",
                "Skipping Maps scan: needs a SerpAPI key (Settings)")
        return []
    out = []
    for query in config.get("maps_queries", []):
        params = {"engine": "google_maps", "type": "search", "q": query,
                  "ll": config.get("maps_location", "@24.4539,54.3773,12z"), "hl": "en", "api_key": key}
        data, err = get_json("https://serpapi.com/search.json?" + urllib.parse.urlencode(params), timeout=40)
        if err:
            if log:
                log(f"فشل فحص الخرائط «{query}»: {err}", f"Maps query '{query}' failed: {err}")
            continue
        listings = (data or {}).get("local_results", []) or []
        n = 0
        for item in listings:
            site = item.get("website")
            if not site:
                continue
            n += 1
            title = item.get("title", "")
            extra = [sig("maps_listing", 0.05, f"موقع مرتبط بإدراج على خرائط Google: «{title}»",
                         f"Website linked from a Google Maps listing: '{title}'", "discovery",
                         detail=item.get("phone", ""))]
            host = hostname(site)
            for b in config.get("brands", []):
                names = [b["name_en"].lower()] + [n_.lower() for n_ in b.get("content_names", [])]
                if any(nm and nm in title.lower() for nm in names) and not official_for_any_brand(host, config) \
                        and not is_allowlisted(host, config):
                    extra.append(sig(f"maps_impersonation:{b['id']}", 0.5,
                                     f"إدراج على الخرائط يحمل اسم {b['name_ar']} لكن موقعه الإلكتروني غير رسمي",
                                     f"Maps listing uses the name {b['name_en']} but links to an unofficial website",
                                     "discovery"))
                    break
            out.append(_candidate(site, "maps", f"{title} — {item.get('address', '')}", extra))
        if log:
            log(f"خرائط «{query}»: {len(listings)} إدراجاً، {n} منها بموقع إلكتروني",
                f"Maps '{query}': {len(listings)} listings, {n} with a website")
    return out
