"""The one-click scan: discover -> deduplicate -> check blocklists -> analyse -> rank -> save."""
from __future__ import annotations

import concurrent.futures as cf
import datetime as dt
import threading
import time
import uuid

from . import analyzer, intel, scoring, sources, storage
from .util import hostname, normalize_url, registered_domain

SOURCE_PRIORITY = {"manual": 0, "ct": 1, "typosquat": 2, "maps": 3, "search_ad": 4, "search": 5}

JOBS: dict[str, "Job"] = {}
_jobs_lock = threading.Lock()


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


class Job:
    def __init__(self, kind: str):
        self.id = uuid.uuid4().hex[:10]
        self.kind = kind
        self.status = "running"
        self.stage = ""
        self.progress = 0
        self.started_at = _now()
        self.finished_at = None
        self.logs: list[dict] = []
        self.results: list[dict] = []
        self.summary: dict = {}
        self.cancelled = False
        self._lock = threading.Lock()

    def log(self, ar: str, en: str) -> None:
        with self._lock:
            self.logs.append({"t": time.strftime("%H:%M:%S"), "ar": ar, "en": en})

    def set_stage(self, stage: str, progress: int, ar: str, en: str) -> None:
        self.stage = stage
        self.progress = progress
        self.log(ar, en)

    def snapshot(self, since_log: int = 0) -> dict:
        with self._lock:
            return {
                "id": self.id, "kind": self.kind, "status": self.status, "stage": self.stage,
                "progress": self.progress, "started_at": self.started_at, "finished_at": self.finished_at,
                "logs": self.logs[since_log:], "log_count": len(self.logs),
                "results": sorted(self.results, key=lambda r: -r.get("score", 0)),
                "summary": self.summary,
            }


def get_job(job_id: str) -> Job | None:
    with _jobs_lock:
        return JOBS.get(job_id)


def _register(job: Job) -> None:
    with _jobs_lock:
        JOBS[job.id] = job
        # keep memory bounded
        if len(JOBS) > 20:
            for old in sorted(JOBS.values(), key=lambda j: j.started_at)[:-20]:
                JOBS.pop(old.id, None)


def _dedupe(candidates: list[dict]) -> list[dict]:
    merged: dict[str, dict] = {}
    for c in candidates:
        url = normalize_url(c["url"])
        if not url:
            continue
        key = hostname(url)
        if key not in merged:
            merged[key] = {"url": url, "sources": [c["source"]], "contexts": [c.get("context", "")],
                           "extra_signals": list(c.get("extra_signals", []))}
        else:
            m = merged[key]
            # Prefer the exact URL from the more specific source (e.g. manual over ct).
            if SOURCE_PRIORITY.get(c["source"], 9) < min(SOURCE_PRIORITY.get(s, 9) for s in m["sources"]):
                m["url"] = url
            if c["source"] not in m["sources"]:
                m["sources"].append(c["source"])
            if c.get("context") and c["context"] not in m["contexts"]:
                m["contexts"].append(c["context"])
            have = {s["id"] for s in m["extra_signals"]}
            m["extra_signals"] += [s for s in c.get("extra_signals", []) if s["id"] not in have]
    items = list(merged.values())
    items.sort(key=lambda m: min(SOURCE_PRIORITY.get(s, 9) for s in m["sources"]))
    return items


def _summarize(job: Job, n_candidates: int, t0: float) -> dict:
    counts = {"fraud": 0, "suspicious": 0, "low": 0, "official": 0}
    by_source: dict[str, int] = {}
    for r in job.results:
        counts[r.get("verdict", "low")] = counts.get(r.get("verdict", "low"), 0) + 1
        for s in r.get("sources", []):
            by_source[s] = by_source.get(s, 0) + 1
    return {"total": len(job.results), "candidates": n_candidates, "verdicts": counts,
            "by_source": by_source, "duration_seconds": int(time.time() - t0)}


def _run(job: Job, config: dict, settings: dict, params: dict) -> None:
    t0 = time.time()
    scan_cfg = config.get("scan", {})
    stages = params.get("stages") or {}
    enabled = lambda name: stages.get(name, True)  # noqa: E731
    candidates: list[dict] = []
    storage.save_scan(job.id, job.kind, job.started_at, "running", {})
    try:
        for raw in params.get("urls", []) or []:
            if raw.strip():
                candidates.append({"url": raw.strip(), "source": "manual", "context": "", "extra_signals": []})

        if job.kind == "full":
            if enabled("ct") and not job.cancelled:
                job.set_stage("ct", 3, "١) فحص سجلات شهادات الأمان (Certificate Transparency) بحثاً عن مواقع جديدة تنتحل الجهات المحمية…",
                              "1) Scanning Certificate Transparency logs for new sites impersonating protected brands…")
                kws = [(b, k) for b in config.get("brands", []) for k in b.get("ct_keywords", [])]
                for i, (b, kw) in enumerate(kws):
                    if job.cancelled:
                        break
                    found, err = sources.ct_search(kw, config, scan_cfg.get("ct_days", 30), scan_cfg.get("ct_max_per_keyword", 40))
                    if err:
                        job.log(f"   سجلات الشهادات «{kw}»: تعذّر الاتصال ({err[:80]})", f"   CT '{kw}': unavailable ({err[:80]})")
                    else:
                        job.log(f"   سجلات الشهادات «{kw}»: {len(found)} نطاقاً جديداً مشبوهاً", f"   CT '{kw}': {len(found)} new suspicious domains")
                    candidates += found
                    job.progress = 3 + int(17 * (i + 1) / max(1, len(kws)))

            if enabled("typosquat") and not job.cancelled:
                job.set_stage("typosquat", 20, "٢) توليد النطاقات المشابهة للمواقع الرسمية والتحقق من المُفعَّل منها…",
                              "2) Generating look-alike domains of official sites and checking which are live…")
                candidates += sources.typosquat_sweep(config, scan_cfg.get("typosquat_max_per_brand", 60), job.log)

            if enabled("search") and not job.cancelled:
                job.set_stage("search", 35, "٣) فحص نتائج محركات البحث والإعلانات…", "3) Scanning search-engine results and ads…")
                candidates += sources.search_scan(config, settings, job.log)

            if enabled("maps") and not job.cancelled:
                job.set_stage("maps", 50, "٤) فحص إدراجات خرائط Google…", "4) Scanning Google Maps listings…")
                candidates += sources.maps_scan(config, settings, job.log)

        items = _dedupe(candidates)
        cap = scan_cfg.get("max_urls_to_analyze", 250)
        if len(items) > cap:
            job.log(f"تم اختيار أهم {cap} رابطاً من أصل {len(items)}", f"Selected the top {cap} of {len(items)} links")
            items = items[:cap]

        gsb_hits: dict = {}
        if settings.get("gsb_key") and items and not job.cancelled:
            gsb_hits, err = intel.safe_browsing_lookup([i["url"] for i in items], settings["gsb_key"])
            job.log(f"Google Safe Browsing: {len(gsb_hits)} تطابق" + (f" (خطأ: {err})" if err else ""),
                    f"Google Safe Browsing: {len(gsb_hits)} matches" + (f" (error: {err})" if err else ""))

        job.set_stage("analyze", 55, f"٥) تحليل {len(items)} رابطاً بعمق (النطاق، الشهادة، محتوى الصفحة، الذكاء الاصطناعي)…",
                      f"5) Deep-analysing {len(items)} links (domain, certificate, page content, AI)…")
        done = 0
        with cf.ThreadPoolExecutor(max_workers=scan_cfg.get("workers", 10)) as pool:
            futs = {pool.submit(analyzer.analyze, it["url"], config, settings, True, gsb_hits,
                                it["extra_signals"], it["sources"]): it for it in items}
            for fut in cf.as_completed(futs):
                it = futs[fut]
                try:
                    r = fut.result()
                except Exception as exc:  # noqa: BLE001
                    r = {"url": it["url"], "score": 0, "verdict": "low", "signals": [], "evidence": {},
                         "sources": it["sources"], "errors": [f"internal: {exc}"], "analyzed_at": _now(),
                         "verdict_ar": "خطأ", "verdict_en": "Error", "host": hostname(it["url"]),
                         "registered_domain": registered_domain(hostname(it["url"]))}
                r["contexts"] = [c for c in it["contexts"] if c]
                r["evidence"]["first_seen"] = storage.first_seen(r.get("registered_domain", "")) or r["analyzed_at"]
                with job._lock:
                    job.results.append(r)
                done += 1
                job.progress = 55 + int(40 * done / max(1, len(items)))
                if job.cancelled:
                    for f in futs:
                        f.cancel()
                    break

        if settings.get("vt_key") and not job.cancelled:
            top = [r for r in sorted(job.results, key=lambda r: -r["score"]) if 40 <= r["score"]][: scan_cfg.get("vt_max_lookups", 4)]
            for r in top:
                stats, err = intel.virustotal_domain(r["registered_domain"], settings["vt_key"])
                if stats:
                    r["evidence"]["virustotal"] = stats
                    new = intel.virustotal_signals(stats)
                    if new:
                        r["signals"] = new + r["signals"]
                        r["score"], r["verdict"] = scoring.score(r["signals"])
                        r["verdict_ar"] = scoring.VERDICTS[r["verdict"]]["ar"]
                        r["verdict_en"] = scoring.VERDICTS[r["verdict"]]["en"]
            if top:
                job.log(f"VirusTotal: فُحص {len(top)} نطاقاً من الأعلى خطورة", f"VirusTotal: checked the {len(top)} riskiest domains")

        for r in job.results:
            storage.save_result(job.id, r)
        job.summary = _summarize(job, len(items), t0)
        job.status = "cancelled" if job.cancelled else "done"
        v = job.summary["verdicts"]
        job.set_stage("done", 100,
                      f"✔ اكتمل الفحص خلال {job.summary['duration_seconds']} ثانية: {v['fraud']} احتيالي، {v['suspicious']} مشبوه، {v['low']} منخفض الخطورة",
                      f"✔ Scan finished in {job.summary['duration_seconds']}s: {v['fraud']} likely fraud, {v['suspicious']} suspicious, {v['low']} low risk")
    except Exception as exc:  # noqa: BLE001
        job.status = "error"
        job.log(f"خطأ غير متوقع: {exc}", f"Unexpected error: {exc}")
        job.summary = _summarize(job, len(candidates), t0)
    finally:
        job.finished_at = _now()
        storage.save_scan(job.id, job.kind, job.started_at, job.status, job.summary, job.finished_at)


def start(kind: str, config: dict, settings: dict, params: dict) -> Job:
    job = Job(kind)
    _register(job)
    threading.Thread(target=_run, args=(job, config, settings, params), daemon=True, name=f"job-{job.id}").start()
    return job
