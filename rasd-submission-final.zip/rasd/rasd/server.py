"""Local web server (standard library only). Serves the dashboard and a small JSON API."""
from __future__ import annotations

import json
import mimetypes
import os
import re
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import __version__, config as cfgmod, pipeline, report, scoring, storage
from .util import extract_urls

STATIC_DIR = os.path.join(cfgmod.BASE_DIR, "static")


class Handler(BaseHTTPRequestHandler):
    server_version = "Rasd/" + __version__

    def log_message(self, fmt, *args):  # keep the console quiet
        pass

    # ------------------------------------------------------------------ helpers
    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > 2_000_000:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except ValueError:
            return {}

    def _same_origin(self) -> bool:
        """Block cross-site requests from other web pages to this local API."""
        origin = self.headers.get("Origin")
        if not origin:
            return True
        host = self.headers.get("Host", "")
        return urllib.parse.urlsplit(origin).netloc == host

    # ------------------------------------------------------------------ routes
    def do_GET(self):  # noqa: N802
        parsed = urllib.parse.urlsplit(self.path)
        path, qs = parsed.path, urllib.parse.parse_qs(parsed.query)

        if path == "/favicon.ico":
            return self._send(204, b"", "image/x-icon")
        if path in ("/", "/index.html"):
            return self._static("index.html")
        if path.startswith("/static/"):
            return self._static(path[len("/static/"):])

        if path == "/api/status":
            config = cfgmod.load_config()
            settings = cfgmod.load_settings()
            return self._json({
                "version": __version__,
                "settings": cfgmod.public_settings(settings),
                "ml_model": scoring.load_model() is not None,
                "brands": [{"id": b["id"], "name_ar": b["name_ar"], "name_en": b["name_en"],
                            "official": b["official_domains"]} for b in config["brands"]],
                "search_queries": config.get("search_queries", []),
                "maps_queries": config.get("maps_queries", []),
            })
        if path == "/api/scans":
            return self._json(storage.list_scans())

        m = re.fullmatch(r"/api/jobs/([a-f0-9]{10})", path)
        if m:
            job = pipeline.get_job(m.group(1))
            if not job:
                return self._json({"error": "not found"}, 404)
            since = int((qs.get("since") or ["0"])[0] or 0)
            return self._json(job.snapshot(since))

        m = re.fullmatch(r"/api/scans/([a-f0-9]{10})/results", path)
        if m:
            return self._json(self._results_for(m.group(1)))

        m = re.fullmatch(r"/api/report/([a-f0-9]{10})\.(html|csv)", path)
        if m:
            scan_id, kind = m.groups()
            results = self._results_for(scan_id)
            scan = next((s for s in storage.list_scans(200) if s["id"] == scan_id), {"id": scan_id})
            job = pipeline.get_job(scan_id)
            if job and job.summary:
                scan["summary"] = job.summary
            if kind == "csv":
                return self._send(200, report.build_csv(results).encode("utf-8"), "text/csv; charset=utf-8",
                                  {"Content-Disposition": f'attachment; filename="rasd-{scan_id}.csv"'})
            lang = (qs.get("lang") or ["ar"])[0]
            return self._send(200, report.build_html(scan, results, lang).encode("utf-8"), "text/html; charset=utf-8")

        if path == "/api/settings":
            return self._json(cfgmod.public_settings(cfgmod.load_settings()))
        return self._json({"error": "not found"}, 404)

    def do_POST(self):  # noqa: N802
        if not self._same_origin():
            return self._json({"error": "forbidden"}, 403)
        path = urllib.parse.urlsplit(self.path).path
        body = self._body()

        if path in ("/api/scan/full", "/api/scan/check"):
            kind = "full" if path.endswith("full") else "check"
            urls = body.get("urls") or []
            if isinstance(urls, list):
                urls = "\n".join(u for u in urls if isinstance(u, str))
            urls = extract_urls(str(urls))[:500]
            if kind == "check" and not urls:
                return self._json({"error": "no urls"}, 400)
            job = pipeline.start(kind, cfgmod.load_config(), cfgmod.load_settings(),
                                 {"urls": urls, "stages": body.get("stages") or {}})
            return self._json({"job_id": job.id})

        m = re.fullmatch(r"/api/jobs/([a-f0-9]{10})/cancel", path)
        if m:
            job = pipeline.get_job(m.group(1))
            if job:
                job.cancelled = True
                job.log("جارٍ إيقاف الفحص…", "Stopping the scan…")
            return self._json({"ok": bool(job)})

        if path == "/api/settings":
            saved = cfgmod.save_settings(body)
            return self._json(cfgmod.public_settings(saved))
        return self._json({"error": "not found"}, 404)

    # ------------------------------------------------------------------ internals
    def _results_for(self, scan_id: str) -> list[dict]:
        job = pipeline.get_job(scan_id)
        if job and job.results:
            return sorted(job.results, key=lambda r: -r.get("score", 0))
        return storage.get_results(scan_id)

    def _static(self, rel: str) -> None:
        full = os.path.realpath(os.path.join(STATIC_DIR, rel))
        if not full.startswith(os.path.realpath(STATIC_DIR) + os.sep) or not os.path.isfile(full):
            return self._json({"error": "not found"}, 404)
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",):
            ctype += "; charset=utf-8"
        with open(full, "rb") as fh:
            self._send(200, fh.read(), ctype)


def make_server(host: str = "127.0.0.1", port: int = 8765) -> ThreadingHTTPServer:
    storage.init()
    mimetypes.add_type("application/javascript", ".js")
    mimetypes.add_type("text/css", ".css")
    return ThreadingHTTPServer((host, port), Handler)
