"""Rasd - early detection of fraudulent links and websites (ScamShield AI hackathon MVP)."""

__version__ = "1.0.0"
