"""Combine signals into one explainable 0-100 risk score, plus the optional ML model."""
from __future__ import annotations

import json
import math
import os
from typing import Optional

from .features import ml_vector
from .signals import sig

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "model_weights.json")
_model_cache: dict = {"loaded": False, "model": None}

VERDICTS = {
    "official": {"ar": "رسمي", "en": "Official", "level": 0},
    "low": {"ar": "منخفض الخطورة", "en": "Low risk", "level": 1},
    "suspicious": {"ar": "مشبوه", "en": "Suspicious", "level": 2},
    "fraud": {"ar": "احتيالي على الأرجح", "en": "Likely fraud", "level": 3},
}


def load_model() -> Optional[dict]:
    if not _model_cache["loaded"]:
        _model_cache["loaded"] = True
        try:
            with open(MODEL_PATH, encoding="utf-8") as fh:
                _model_cache["model"] = json.load(fh)
        except (OSError, ValueError):
            _model_cache["model"] = None
    return _model_cache["model"]


def ml_probability(url: str) -> Optional[float]:
    """Logistic-regression phishing probability using weights from tools/train_model.py."""
    model = load_model()
    if not model:
        return None
    v = ml_vector(url)
    z = model.get("intercept", 0.0)
    for name, coef in model.get("coefficients", {}).items():
        mean = model.get("mean", {}).get(name, 0.0)
        std = model.get("std", {}).get(name, 1.0) or 1.0
        z += coef * ((float(v.get(name, 0.0)) - mean) / std)
    z = max(-30.0, min(30.0, z))
    return 1.0 / (1.0 + math.exp(-z))


def ml_signal(p: Optional[float]) -> list[dict]:
    if p is None or p < 0.6:
        return []
    return [sig("ml_model", min(0.5, (p - 0.5) * 1.0), f"نموذج التعلم الآلي يقدّر احتمال التصيّد بـ {int(p * 100)}%",
                f"Machine-learning model estimates {int(p * 100)}% phishing probability", "ai")]


def score(signals: list[dict]) -> tuple[int, str]:
    """Noisy-OR: each risk signal independently pushes the score up; trust signals pull it down."""
    if any(s["id"] == "official_domain" for s in signals):
        return 0, "official"
    keep = 1.0
    for s in signals:
        if not s["trust"]:
            keep *= (1.0 - s["weight"])
    risk = 1.0 - keep
    # Intel hits from external blocklists are not reduced by trust signals.
    hard = any(s["id"] in ("gsb_match", "vt_malicious") for s in signals)
    if not hard:
        for s in signals:
            if s["trust"]:
                risk *= (1.0 - s["weight"])
    value = int(round(risk * 100))
    if value >= 70:
        return value, "fraud"
    if value >= 40:
        return value, "suspicious"
    return value, "low"
