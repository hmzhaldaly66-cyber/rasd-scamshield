"""Analyse one URL end to end: URL text -> DNS -> page -> TLS -> domain age -> intel -> AI -> score."""
from __future__ import annotations

import datetime as dt
import ipaddress
import urllib.parse

from . import content, features, intel, netcheck, scoring
from .signals import sig
from .util import decode_body, hostname, normalize_url, registered_domain


def _is_internal(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.is_private or a.is_loopback or a.is_link_local or a.is_reserved or a.is_multicast or a.is_unspecified


def _merge(signals: list[dict], new: list[dict], suffix: str = "") -> None:
    have = {s["id"] for s in signals}
    for s in new:
        if s["id"] in have:
            continue
        if suffix:
            s = dict(s, detail=(s.get("detail") or suffix))
        signals.append(s)
        have.add(s["id"])


def analyze(raw_url: str, config: dict, settings: dict | None = None, deep: bool = True,
            gsb_hits: dict | None = None, extra_signals: list[dict] | None = None,
            sources: list[str] | None = None) -> dict:
    settings = settings or {}
    scan_cfg = config.get("scan", {})
    url = normalize_url(raw_url)
    now = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    if not url:
        return {"url": raw_url, "error": "invalid URL", "score": 0, "verdict": "low",
                "signals": [], "evidence": {}, "sources": sources or [], "analyzed_at": now}

    signals, evidence = features.analyze_url(url, config)
    host = evidence["host"]
    reg = evidence["registered_domain"]
    errors: list[str] = []
    final_url = url
    is_official = any(s["id"] == "official_domain" for s in signals)
    allowlisted = any(s["id"] == "allowlisted" for s in signals)

    if extra_signals:
        _merge(signals, extra_signals)

    if deep and not is_official:
        ips = netcheck.resolve(host)
        evidence["ips"] = ips[:5]
        page = None
        internal = [ip for ip in ips if _is_internal(ip)]
        if internal:
            # Never make requests into the local/private network on behalf of an untrusted link.
            _merge(signals, [sig("internal_ip", 0.1, f"الرابط يشير إلى عنوان شبكة داخلية ({internal[0]}) — لم يُفتح للسلامة",
                                 f"Link points to an internal network address ({internal[0]}) — not opened for safety",
                                 "domain")])
            ips = []
            evidence["ips"] = internal[:5]
            deep_net = False
        else:
            deep_net = True
        if ips and deep_net:
            page = netcheck.fetch_page(url, timeout=scan_cfg.get("fetch_timeout_seconds", 10),
                                       max_bytes=scan_cfg.get("max_page_bytes", 2_000_000))
            if page["error"] and not page["body"] and url.lower().startswith("https://"):
                retry = netcheck.fetch_page("http://" + url[8:], timeout=scan_cfg.get("fetch_timeout_seconds", 10),
                                            max_bytes=scan_cfg.get("max_page_bytes", 2_000_000))
                if retry["body"]:
                    page = retry
            if page["error"] and not page["body"]:
                errors.append(f"fetch: {page['error']}")
            final_url = page.get("url") or url
            evidence["http_status"] = page.get("status")
            evidence["redirects"] = page.get("redirects", [])[:6]
            if page.get("tls_fallback"):
                _merge(signals, [sig("tls_untrusted_fetch", 0.2, "تعذّر التحقق من شهادة الأمان عند فتح الصفحة",
                                     "Certificate could not be verified when loading the page", "domain")])

        final_host = hostname(final_url)
        if final_host and registered_domain(final_host) != reg:
            evidence["final_url"] = final_url
            final_signals, final_ev = features.analyze_url(final_url, config)
            if any(s["id"] == "official_domain" for s in final_signals):
                _merge(signals, [sig("redirects_to_official", 0.6,
                                     f"الرابط يحوّل إلى الموقع الرسمي ({final_host})",
                                     f"Link redirects to the official site ({final_host})", "domain", trust=True)])
            else:
                _merge(signals, [sig("cross_domain_redirect", 0.15, f"الرابط يحوّل إلى نطاق آخر: {final_host}",
                                     f"Link redirects to another domain: {final_host}", "domain",
                                     detail=final_url)])
                _merge(signals, [s for s in final_signals if not s["trust"]], suffix=f"final: {final_host}")
                evidence.setdefault("impersonated_brands", final_ev.get("impersonated_brands", []))

        target_host = final_host or host
        target_reg = registered_domain(target_host)
        final_is_official = features.official_for_any_brand(target_host, config) is not None

        if page and page["body"] and not final_is_official:
            ctype = page["headers"].get("content-type", "")
            if "html" in ctype or page["body"].lstrip()[:15].lower().startswith((b"<!doctype", b"<html")) or not ctype:
                html = decode_body(page["body"], page["headers"])
                c_signals, c_ev = content.analyze_content(final_url, html, config)
                _merge(signals, c_signals)
                evidence["page"] = c_ev

        if ips and not allowlisted and not final_is_official:
            if urllib.parse.urlsplit(final_url).scheme == "https" or not page:
                tls = netcheck.tls_info(target_host)
                evidence["tls"] = tls
            else:
                tls = {}
            rdap = netcheck.rdap_domain(target_reg)
            evidence["domain"] = rdap
            _merge(signals, netcheck.domain_signals(rdap, tls, ips))
        elif not ips and deep_net:
            _merge(signals, netcheck.domain_signals({}, {}, ips))
            errors.append("DNS: domain does not resolve")

    # External blocklists (batch results computed by the pipeline).
    if gsb_hits:
        threats = gsb_hits.get(url) or gsb_hits.get(final_url)
        if threats:
            _merge(signals, [intel.safe_browsing_signal(threats)])

    # Optional machine-learning model on the URL text.
    if not is_official:
        p = scoring.ml_probability(final_url if final_url else url)
        if p is not None:
            evidence["ml_probability"] = round(p, 3)
            _merge(signals, scoring.ml_signal(p))

    value, verdict = scoring.score(signals)

    # Optional AI review for pages that already look questionable (saves API calls).
    if deep and settings.get("anthropic_key") and value >= 25 and evidence.get("page"):
        pg = evidence["page"]
        forms = f"{pg.get('forms', 0)} forms, password={pg.get('has_password_field')}, card={pg.get('has_card_fields')}, otp={pg.get('has_otp_field')}"
        review, err = intel.llm_review(final_url, pg.get("title", ""), pg.get("text_sample", ""), forms,
                                       settings["anthropic_key"], settings.get("anthropic_model") or "claude-haiku-5-5")
        if err:
            errors.append(f"AI: {err}")
        if review:
            evidence["ai_review"] = review
            _merge(signals, intel.llm_signal(review))
            value, verdict = scoring.score(signals)

    signals.sort(key=lambda s: (s["trust"], -s["weight"]))
    v = scoring.VERDICTS[verdict]
    return {
        "url": url,
        "final_url": final_url,
        "host": host,
        "registered_domain": reg,
        "score": value,
        "verdict": verdict,
        "verdict_ar": v["ar"],
        "verdict_en": v["en"],
        "signals": signals,
        "evidence": evidence,
        "sources": sources or ["manual"],
        "errors": errors,
        "analyzed_at": now,
    }
