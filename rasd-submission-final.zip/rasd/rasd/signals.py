"""Signal helper. A signal is one explainable piece of evidence with a weight in [0, 1].

Positive weights raise risk; signals with ``trust=True`` lower it.
"""
from __future__ import annotations


def sig(sid: str, weight: float, ar: str, en: str, category: str, trust: bool = False,
        detail: str = "") -> dict:
    return {
        "id": sid,
        "weight": round(max(0.0, min(1.0, weight)), 3),
        "ar": ar,
        "en": en,
        "category": category,  # url | domain | content | intel | ai | discovery
        "trust": trust,
        "detail": detail,
    }
