"""Static HTML analysis of a fetched page (no JavaScript is executed)."""
from __future__ import annotations

import re
import urllib.parse
from html.parser import HTMLParser

from .features import is_official, official_for_any_brand
from .signals import sig
from .util import hostname, registered_domain

CARD_PATTERNS = re.compile(
    r"card.?num|cc.?num|cardnumber|creditcard|cvv|cvc|csc|security.?code|expir|exp.?date|"
    r"mm.?yy|رقم.?البطاقة|البطاقة|تاريخ.?الانتهاء|الرمز.?السري.?للبطاقة", re.I)
OTP_PATTERNS = re.compile(r"\botp\b|one.?time|sms.?code|verification.?code|رمز.?التحقق|رمز.?التأكيد|كلمة.?المرور.?المؤقتة", re.I)
ID_PATTERNS = re.compile(r"emirates.?id|\beid\b|رقم.?الهوية|الهوية.?الإماراتية|passport|جواز", re.I)

SCAM_PHRASES = [
    # Arabic
    "مخالفة", "مخالفات", "غرامة", "سداد", "ادفع الآن", "ادفع فوراً", "تم إيقاف", "سيتم إيقاف",
    "تحديث بيانات", "تحديث البيانات", "خلال 24 ساعة", "شحنتك", "رسوم جمركية", "رسوم التوصيل",
    "جائزة", "مبروك", "ربحت", "استرداد", "حسابك موقوف", "تعليق حسابك", "إعادة جدولة التسليم",
    "عرض لفترة محدودة", "آخر فرصة",
    # English
    "pay now", "pay your fine", "outstanding fine", "suspended", "verify your account",
    "within 24 hours", "your parcel", "customs fee", "delivery fee", "you have won",
    "claim your", "refund", "unusual activity", "confirm your identity", "account locked",
    "reschedule delivery", "limited time", "final notice", "avoid penalty",
]


class _PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title = ""
        self._in_title = False
        self._skip = 0
        self.text_parts: list[str] = []
        self.forms: list[dict] = []
        self._form: dict | None = None
        self.inputs: list[dict] = []
        self.links: list[str] = []
        self.resources: list[str] = []
        self.scripts_inline: list[str] = []
        self._in_script = False
        self.meta_refresh = ""
        self.iframes = 0

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "title":
            self._in_title = True
        elif tag in ("script", "style", "noscript"):
            self._skip += 1
            if tag == "script":
                self._in_script = True
                if a.get("src"):
                    self.resources.append(a["src"])
        elif tag == "form":
            self._form = {"action": a.get("action", ""), "method": a.get("method", "get").lower(), "inputs": []}
            self.forms.append(self._form)
        elif tag in ("input", "select", "textarea"):
            field = {"type": a.get("type", "text" if tag == "input" else tag).lower(),
                     "name": a.get("name", ""), "id": a.get("id", ""),
                     "placeholder": a.get("placeholder", ""), "autocomplete": a.get("autocomplete", ""),
                     "aria": a.get("aria-label", "")}
            self.inputs.append(field)
            if self._form is not None:
                self._form["inputs"].append(field)
        elif tag == "a" and a.get("href"):
            self.links.append(a["href"])
        elif tag in ("img", "link") and (a.get("src") or a.get("href")):
            self.resources.append(a.get("src") or a.get("href"))
        elif tag == "meta" and a.get("http-equiv", "").lower() == "refresh":
            self.meta_refresh = a.get("content", "")
        elif tag == "iframe":
            self.iframes += 1

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag in ("script", "style", "noscript"):
            self._skip = max(0, self._skip - 1)
            self._in_script = False
        elif tag == "form":
            self._form = None

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif self._in_script:
            if sum(len(s) for s in self.scripts_inline) < 300_000:
                self.scripts_inline.append(data)
        elif not self._skip:
            t = data.strip()
            if t and sum(len(p) for p in self.text_parts) < 60_000:
                self.text_parts.append(t)


def parse_html(html: str) -> _PageParser:
    p = _PageParser()
    try:
        p.feed(html)
        p.close()
    except Exception:
        pass  # malformed HTML: keep whatever was parsed
    return p


def _field_text(f: dict) -> str:
    return " ".join([f["name"], f["id"], f["placeholder"], f["autocomplete"], f["aria"]])


def analyze_content(page_url: str, html: str, config: dict) -> tuple[list[dict], dict]:
    signals: list[dict] = []
    p = parse_html(html)
    host = hostname(page_url)
    reg = registered_domain(host)
    title = re.sub(r"\s+", " ", p.title).strip()[:200]
    text = " ".join(p.text_parts)
    text_lower = text.lower()
    html_lower = html.lower()
    official = official_for_any_brand(host, config)

    has_password = any(f["type"] == "password" for f in p.inputs)
    has_card = any(CARD_PATTERNS.search(_field_text(f)) for f in p.inputs) or \
        any(f["autocomplete"].startswith("cc-") for f in p.inputs)
    has_otp = any(OTP_PATTERNS.search(_field_text(f)) for f in p.inputs) or \
        any(f["autocomplete"] == "one-time-code" for f in p.inputs)
    has_id = any(ID_PATTERNS.search(_field_text(f)) for f in p.inputs)

    evidence = {
        "title": title,
        "forms": len(p.forms),
        "inputs": len(p.inputs),
        "has_password_field": has_password,
        "has_card_fields": has_card,
        "has_otp_field": has_otp,
        "links": len(p.links),
        "text_sample": text[:400],
    }
    if official:
        return signals, evidence

    if has_card:
        signals.append(sig("card_fields", 0.35, "الصفحة تطلب بيانات بطاقة مصرفية (رقم البطاقة / CVV / تاريخ الانتهاء)",
                           "Page asks for payment card details (number / CVV / expiry)", "content"))
    if has_otp:
        signals.append(sig("otp_field", 0.2, "الصفحة تطلب رمز تحقق لمرة واحدة (OTP)",
                           "Page asks for a one-time verification code (OTP)", "content"))
    if has_password:
        signals.append(sig("password_field", 0.12, "الصفحة تحتوي حقل كلمة مرور",
                           "Page contains a password field", "content"))
    if has_id:
        signals.append(sig("id_fields", 0.12, "الصفحة تطلب رقم الهوية أو الجواز",
                           "Page asks for Emirates ID / passport number", "content"))

    # Where do the forms send the data?
    for f in p.forms:
        action = f["action"].strip()
        if not action or action.startswith("#") or action.lower().startswith("javascript"):
            continue
        target = urllib.parse.urljoin(page_url, action)
        t_host = hostname(target)
        if t_host and registered_domain(t_host) != reg:
            signals.append(sig("form_external", 0.25, f"النموذج يرسل البيانات إلى نطاق آخر: {t_host}",
                               f"Form submits data to a different domain: {t_host}", "content", detail=target))
            break

    if "api.telegram.org" in html_lower or "telegram.org/bot" in html_lower:
        signals.append(sig("telegram_exfil", 0.5, "الصفحة ترسل البيانات إلى بوت تيليجرام (أسلوب شائع في أدوات التصيّد)",
                           "Page sends data to a Telegram bot (common phishing-kit technique)", "content"))
    if re.search(r"eval\s*\(\s*(atob|unescape|decodeURIComponent)|document\.write\s*\(\s*unescape|"
                 r"\\x[0-9a-f]{2}\\x[0-9a-f]{2}\\x[0-9a-f]{2}\\x[0-9a-f]{2}", html_lower):
        signals.append(sig("obfuscated_js", 0.15, "كود JavaScript مشفّر/مموّه لإخفاء سلوك الصفحة",
                           "Obfuscated JavaScript used to hide page behaviour", "content"))
    if re.search(r"(oncontextmenu\s*=\s*[\"']?\s*return\s+false)|addEventListener\(\s*[\"']contextmenu", html_lower):
        signals.append(sig("no_right_click", 0.08, "الصفحة تمنع الزر الأيمن للفأرة (لإعاقة الفحص)",
                           "Page blocks right-click (to hinder inspection)", "content"))
    if p.meta_refresh and "url=" in p.meta_refresh.lower():
        target = p.meta_refresh.split("=", 1)[-1].strip(" '\"")
        t_host = hostname(urllib.parse.urljoin(page_url, target))
        if t_host and registered_domain(t_host) != reg:
            signals.append(sig("meta_redirect", 0.12, f"الصفحة تعيد التوجيه تلقائياً إلى {t_host}",
                               f"Page auto-redirects to {t_host}", "content"))

    # Brand impersonation through content.
    brand_hits = []
    for b in config.get("brands", []):
        names = [n.lower() for n in b.get("content_names", []) if n]
        name_hit = any(n in title.lower() or n in text_lower[:20000] for n in names)
        hotlink = False
        for r in p.resources:
            r_host = hostname(urllib.parse.urljoin(page_url, r))
            if r_host and is_official(r_host, b):
                hotlink = True
                break
        if name_hit or hotlink:
            brand_hits.append((b, name_hit, hotlink))

    sensitive_form = has_card or has_password or has_otp or has_id
    for b, name_hit, hotlink in brand_hits[:2]:
        if hotlink:
            signals.append(sig(f"brand_assets:{b['id']}", 0.35,
                               f"الصفحة تحمّل شعارات/ملفات من موقع {b['name_ar']} الرسمي مع أنها ليست الموقع الرسمي",
                               f"Page loads logos/assets from the official {b['name_en']} site while not being it",
                               "content"))
        if name_hit and sensitive_form:
            signals.append(sig(f"brand_form:{b['id']}", 0.5,
                               f"الصفحة تنتحل اسم {b['name_ar']} وتطلب بيانات حساسة على نطاق غير رسمي",
                               f"Page uses the {b['name_en']} name and asks for sensitive data on an unofficial domain",
                               "content"))
        elif name_hit and title and any(n.lower() in title.lower() for n in b.get("content_names", [])):
            signals.append(sig(f"brand_title:{b['id']}", 0.15,
                               f"عنوان الصفحة يحمل اسم {b['name_ar']} على نطاق غير رسمي",
                               f"Page title carries the {b['name_en']} name on an unofficial domain", "content"))
    if brand_hits:
        evidence["brands_in_content"] = [b["name_en"] for b, _, _ in brand_hits]

    phrases = [ph for ph in SCAM_PHRASES if ph in text_lower or ph in title.lower()]
    if len(phrases) >= 4:
        signals.append(sig("scam_language", 0.25, f"لغة احتيال وضغط واستعجال: {'، '.join(phrases[:5])}",
                           f"Scam/urgency language: {', '.join(phrases[:5])}", "content"))
    elif len(phrases) >= 2:
        signals.append(sig("scam_language_some", 0.12, f"عبارات تُستخدم كثيراً في الاحتيال: {'، '.join(phrases[:4])}",
                           f"Phrases often used in scams: {', '.join(phrases[:4])}", "content"))
    if phrases:
        evidence["scam_phrases"] = phrases[:8]

    if sensitive_form and len(p.links) <= 3:
        signals.append(sig("bare_page", 0.1, "صفحة شبه فارغة من الروابط تحتوي نموذج بيانات فقط (نمط صفحات التصيّد)",
                           "Page has almost no links besides a data form (phishing-page pattern)", "content"))
    return signals, evidence
