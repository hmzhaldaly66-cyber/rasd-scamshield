"""Network intelligence: DNS, domain age (RDAP), TLS certificate, page fetch."""
from __future__ import annotations

import concurrent.futures as cf
import datetime as dt
import socket
import ssl
import threading
from typing import Optional

from .signals import sig
from .util import _ssl_context, get_json, http_request, is_hosting_domain, is_ip

_DNS_POOL = cf.ThreadPoolExecutor(max_workers=32, thread_name_prefix="dns")
_rdap_cache: dict[str, dict] = {}
_rdap_lock = threading.Lock()


def resolve(host: str, timeout: float = 4.0) -> list[str]:
    """Resolve a hostname to IPs with a hard timeout. Returns [] if it does not resolve."""
    if is_ip(host):
        return [host]

    def _lookup():
        infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
        return sorted({i[4][0] for i in infos})

    fut = _DNS_POOL.submit(_lookup)
    try:
        return fut.result(timeout=timeout)
    except Exception:
        return []


def _parse_date(s: str) -> Optional[dt.datetime]:
    if not s:
        return None
    s = s.strip().replace("Z", "+00:00")
    for fmt in (None, "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d"):
        try:
            d = dt.datetime.fromisoformat(s) if fmt is None else dt.datetime.strptime(s, fmt)
            if d.tzinfo is None:
                d = d.replace(tzinfo=dt.timezone.utc)
            return d
        except ValueError:
            continue
    return None


def rdap_domain(domain: str) -> dict:
    """Registration date and registrar via RDAP (the modern, JSON replacement for WHOIS)."""
    if is_ip(domain) or is_hosting_domain(domain):
        return {"available": False, "reason": "not applicable"}
    with _rdap_lock:
        if domain in _rdap_cache:
            return _rdap_cache[domain]
    data, err = get_json(f"https://rdap.org/domain/{domain}", timeout=15)
    info: dict = {"available": False}
    if data and isinstance(data, dict):
        info["available"] = True
        for ev in data.get("events", []) or []:
            action = (ev.get("eventAction") or "").lower()
            if action == "registration":
                info["created"] = ev.get("eventDate")
            elif action == "expiration":
                info["expires"] = ev.get("eventDate")
        for ent in data.get("entities", []) or []:
            if "registrar" in (ent.get("roles") or []):
                vcard = ent.get("vcardArray") or []
                if len(vcard) == 2:
                    for item in vcard[1]:
                        if item and item[0] == "fn":
                            info["registrar"] = item[3]
        created = _parse_date(info.get("created", ""))
        if created:
            info["age_days"] = (dt.datetime.now(dt.timezone.utc) - created).days
    else:
        info["reason"] = err or "no data"
    with _rdap_lock:
        _rdap_cache[domain] = info
    return info


_trust = {"checked": False, "ok": True}


def trust_store_ok() -> bool:
    """Check once that this computer can verify certificates at all (e.g. macOS python.org
    installs need 'Install Certificates.command'); otherwise every site would look invalid."""
    if not _trust["checked"]:
        _trust["checked"] = True
        for h in ("www.google.com", "www.microsoft.com"):
            try:
                with socket.create_connection((h, 443), timeout=6) as sock:
                    with _ssl_context(True).wrap_socket(sock, server_hostname=h):
                        _trust["ok"] = True
                        return True
            except ssl.SSLCertVerificationError:
                _trust["ok"] = False
                return False
            except OSError:
                continue  # no direct network: leave as ok, tls_info will just be unavailable
    return _trust["ok"]


def tls_info(host: str, port: int = 443, timeout: float = 6.0) -> dict:
    """Inspect the site's TLS certificate (validity, issuer, issue date)."""
    info: dict = {"available": False}
    if not trust_store_ok():
        info["error"] = "local certificate store missing (macOS: run 'Install Certificates.command')"
        return info
    try:
        ctx = _ssl_context(True)
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as tls:
                cert = tls.getpeercert() or {}
        info["available"] = True
        info["valid"] = True
        issuer = dict(x[0] for x in cert.get("issuer", []) if x)
        info["issuer"] = issuer.get("organizationName") or issuer.get("commonName", "")
        nb = cert.get("notBefore")
        if nb:
            not_before = dt.datetime.strptime(nb, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=dt.timezone.utc)
            info["not_before"] = not_before.isoformat()
            info["cert_age_days"] = (dt.datetime.now(dt.timezone.utc) - not_before).days
        info["san_count"] = len(cert.get("subjectAltName", []))
    except ssl.SSLCertVerificationError as exc:
        info.update(available=True, valid=False, error=exc.verify_message or str(exc))
    except (ssl.SSLError, OSError) as exc:
        info["error"] = f"{type(exc).__name__}: {exc}"
    return info


def fetch_page(url: str, timeout: float = 10, max_bytes: int = 2_000_000) -> dict:
    """Download the page HTML (no JavaScript is executed, nothing is submitted)."""
    return http_request(url, timeout=timeout, max_bytes=max_bytes)


def domain_signals(rdap: dict, tls: dict, dns_ips: list[str]) -> list[dict]:
    out = []
    age = rdap.get("age_days")
    if age is not None:
        if age < 30:
            out.append(sig("young_domain_30", 0.45, f"النطاق سُجّل قبل {age} يوماً فقط",
                           f"Domain was registered only {age} days ago", "domain"))
        elif age < 90:
            out.append(sig("young_domain_90", 0.25, f"النطاق حديث التسجيل ({age} يوماً)",
                           f"Recently registered domain ({age} days)", "domain"))
        elif age < 365:
            out.append(sig("young_domain_365", 0.08, f"عمر النطاق أقل من سنة ({age} يوماً)",
                           f"Domain is less than a year old ({age} days)", "domain"))
        elif age > 5 * 365:
            out.append(sig("old_domain", 0.3, f"نطاق قديم ومستقر (عمره {age // 365} سنوات)",
                           f"Long-established domain ({age // 365} years old)", "domain", trust=True))
    if tls.get("available") and tls.get("valid") is False:
        out.append(sig("tls_invalid", 0.25, f"شهادة الأمان (SSL) غير صالحة: {tls.get('error', '')}",
                       f"Invalid TLS certificate: {tls.get('error', '')}", "domain"))
    if tls.get("valid") and tls.get("cert_age_days") is not None and tls["cert_age_days"] < 7:
        out.append(sig("fresh_cert", 0.1, f"شهادة الأمان صدرت قبل {tls['cert_age_days']} أيام",
                       f"TLS certificate issued {tls['cert_age_days']} days ago", "domain"))
    if not dns_ips:
        out.append(sig("no_dns", 0.0, "النطاق لا يعمل حالياً (لا يوجد عنوان DNS) — ربما أُغلق أو لم يُفعَّل بعد",
                       "Domain does not currently resolve (may be taken down or not yet active)", "domain"))
    return out
