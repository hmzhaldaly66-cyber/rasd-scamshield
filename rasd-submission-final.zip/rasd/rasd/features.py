"""Lexical URL analysis and brand-impersonation detection (works fully offline)."""
from __future__ import annotations

import math
import re
import urllib.parse
from collections import Counter

from .signals import sig
from .util import (hostname, host_matches, is_hosting_domain, is_ip, main_label,
                   public_suffix, registered_domain, subdomain_part)

SUSPICIOUS_TLDS = {
    "xyz", "top", "online", "site", "icu", "buzz", "live", "click", "link", "info", "cfd",
    "sbs", "rest", "lol", "cyou", "monster", "quest", "bond", "vip", "tk", "ml", "ga", "cf",
    "gq", "pw", "work", "fit", "loan", "win", "bid", "men", "date", "racing", "review",
    "country", "kim", "science", "party", "trade", "webcam", "support", "help", "cam", "mom",
    "beauty", "hair", "skin", "boats", "autos", "homes", "yachts", "makeup", "zip", "mov",
}

SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.ly", "cutt.ly", "is.gd", "rb.gy", "shorturl.at", "s.id",
    "ow.ly", "tiny.cc", "buff.ly", "rebrand.ly", "bl.ink", "short.io", "v.gd", "qr.ae",
    "t.me", "wa.link", "linktr.ee", "lnkd.in", "goo.su", "u.to", "clck.ru",
}

SENSITIVE_WORDS = [
    "login", "signin", "sign-in", "verify", "verification", "update", "secure", "account",
    "pay", "payment", "fine", "fines", "violation", "traffic", "refund", "wallet", "otp",
    "confirm", "bank", "unlock", "suspend", "suspended", "prize", "reward", "gift", "claim",
    "track", "tracking", "parcel", "delivery", "customs", "invoice", "billing", "kyc",
    "reactivate", "auth", "support", "service", "portal", "redeliver", "fee",
]

# Words that commonly glue onto a brand in phishing domains (e.g. "tamm-pay", "adcbsecure").
COMBO_WORDS = {
    "pay", "ae", "uae", "gov", "online", "portal", "service", "services", "track", "login",
    "secure", "verify", "fine", "fines", "app", "web", "bank", "card", "id", "my", "e",
    "help", "support", "update", "account", "net", "digital", "official", "center", "centre",
}

HOMOGLYPH_SEQS = [("rn", "m"), ("vv", "w"), ("cl", "d"), ("nn", "m")]
HOMOGLYPH_CHARS = str.maketrans({"0": "o", "1": "l", "3": "e", "4": "a", "5": "s",
                                 "7": "t", "8": "b", "9": "g", "$": "s", "@": "a", "!": "i"})


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = Counter(s)
    return -sum((c / len(s)) * math.log2(c / len(s)) for c in counts.values())


def damerau_levenshtein(a: str, b: str) -> int:
    """Optimal string alignment distance (handles adjacent swaps)."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if abs(la - lb) > 3:
        return 99
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]


def deconfuse(label: str) -> str:
    """Normalise look-alike characters: 'adpo1ice' -> 'adpolice', 'sa-lik' -> 'salik'."""
    s = label.lower().translate(HOMOGLYPH_CHARS).replace("-", "").replace("_", "")
    for seq, rep in HOMOGLYPH_SEQS:
        s = s.replace(seq, rep)
    return s


def is_official(host: str, brand: dict) -> bool:
    return any(host_matches(host, d) for d in brand.get("official_domains", []))


def is_allowlisted(host: str, config: dict) -> bool:
    return any(host_matches(host, d) for d in config.get("allowlist_domains", []))


def official_for_any_brand(host: str, config: dict):
    for b in config.get("brands", []):
        if is_official(host, b):
            return b
    return None


def _keyword_in_host(keyword: str, host: str) -> bool:
    kw = keyword.lower()
    flat = re.sub(r"[.\-_]", "", host)
    if len(kw.replace("-", "")) >= 6:
        return kw.replace("-", "") in flat
    tokens = [t for t in re.split(r"[.\-_0-9]+", host) if t]
    for t in tokens:
        if t == kw:
            return True
        if t.startswith(kw) and t[len(kw):] in COMBO_WORDS:
            return True
        if t.endswith(kw) and t[: -len(kw)] in COMBO_WORDS:
            return True
    return False


def brand_matches(host: str, config: dict) -> list[dict]:
    """Find protected brands that a (non-official) host appears to impersonate."""
    reg = registered_domain(host)
    sld = main_label(reg)
    sld_clean = deconfuse(sld)
    host_clean = deconfuse(host.replace(".", "-"))
    found = []
    for brand in config.get("brands", []):
        if is_official(host, brand):
            continue
        if any(host_matches(host, ex) for ex in brand.get("keyword_exceptions", [])):
            continue
        kinds = []
        if any(_keyword_in_host(k, host) for k in brand.get("keywords", [])):
            kinds.append("keyword")
        for od in brand.get("official_domains", []):
            o_sld = main_label(registered_domain(od))
            if len(o_sld) < 4:
                continue
            if sld_clean == o_sld and reg != registered_domain(od):
                kinds.append("same_name_other_tld" if sld == o_sld else "homoglyph")
                break
            if len(o_sld) >= 6:
                dist = damerau_levenshtein(sld_clean, o_sld)
                if 0 < dist <= (2 if len(o_sld) >= 9 else 1):
                    kinds.append("typosquat")
                    break
            if len(o_sld) >= 6 and o_sld in host_clean and "keyword" not in kinds:
                kinds.append("keyword")
                break
        if kinds:
            found.append({"brand": brand, "kinds": sorted(set(kinds))})
    return found


def ml_vector(url: str) -> dict:
    """Numeric URL features used by the optional machine-learning model."""
    host = hostname(url)
    parts = urllib.parse.urlsplit(url)
    reg = registered_domain(host)
    sub = subdomain_part(host)
    path = parts.path or ""
    lower = url.lower()
    tld = reg.rsplit(".", 1)[-1] if "." in reg else ""
    return {
        "url_length": len(url),
        "host_length": len(host),
        "num_dots": host.count("."),
        "num_hyphens_host": host.count("-"),
        "num_digits_host": sum(c.isdigit() for c in host),
        "num_subdomain_labels": len(sub.split(".")) if sub else 0,
        "has_ip": int(is_ip(host)),
        "has_at": int("@" in url),
        "has_punycode": int("xn--" in host),
        "is_https": int(parts.scheme.lower() == "https"),
        "suspicious_tld": int(tld in SUSPICIOUS_TLDS),
        "is_shortener": int(reg in SHORTENERS or host in SHORTENERS),
        "sensitive_words": sum(1 for w in SENSITIVE_WORDS if w in lower),
        "path_length": len(path),
        "path_depth": path.count("/"),
        "num_query_params": len(urllib.parse.parse_qsl(parts.query)),
        "sld_entropy": round(shannon_entropy(main_label(reg)), 3),
        "has_port": int(parts.port is not None and parts.port not in (80, 443)) if _safe_port(parts) else 1,
        "free_hosting": int(is_hosting_domain(reg)),
        "num_special": sum(url.count(c) for c in "%=&~_"),
    }


def _safe_port(parts) -> bool:
    try:
        _ = parts.port
        return True
    except ValueError:
        return False


def analyze_url(url: str, config: dict) -> tuple[list[dict], dict]:
    """Return (signals, evidence) derived purely from the URL text."""
    signals: list[dict] = []
    host = hostname(url)
    reg = registered_domain(host)
    suffix = public_suffix(reg)
    tld = reg.rsplit(".", 1)[-1] if "." in reg else ""
    sub = subdomain_part(host)
    v = ml_vector(url)
    lower = url.lower()
    evidence = {"host": host, "registered_domain": reg, "tld": tld}

    official = official_for_any_brand(host, config)
    if official:
        evidence["official_brand"] = official["name_en"]
        signals.append(sig("official_domain", 0.95, f"نطاق رسمي لـ {official['name_ar']}",
                           f"Official domain of {official['name_en']}", "url", trust=True))
        return signals, evidence

    if is_allowlisted(host, config):
        signals.append(sig("allowlisted", 0.7, "نطاق معروف وموثوق (في قائمة السماح)",
                           "Well-known trusted domain (allowlist)", "url", trust=True))

    if v["has_ip"]:
        signals.append(sig("ip_host", 0.35, "الرابط يستخدم عنوان IP بدلاً من اسم نطاق",
                           "URL uses a raw IP address instead of a domain name", "url"))
    if v["has_punycode"]:
        signals.append(sig("punycode", 0.35, "النطاق يحتوي أحرفاً مموّهة (Punycode) قد تشبه أحرفاً لاتينية",
                           "Domain uses Punycode (possible look-alike characters)", "url"))
    if v["has_at"]:
        signals.append(sig("at_symbol", 0.3, "الرابط يحتوي الرمز @ الذي يُستخدم لإخفاء الوجهة الحقيقية",
                           "URL contains '@', often used to hide the real destination", "url"))
    if v["num_subdomain_labels"] >= 3:
        signals.append(sig("many_subdomains", 0.15, f"عدد كبير من النطاقات الفرعية ({v['num_subdomain_labels']})",
                           f"Many subdomain levels ({v['num_subdomain_labels']})", "url", detail=sub))
    hy = reg.replace("xn--", "").count("-")
    if hy >= 3:
        signals.append(sig("many_hyphens", 0.15, f"النطاق يحتوي {hy} شَرطات (نمط شائع في نطاقات الاحتيال)",
                           f"Domain contains {hy} hyphens (common in fraud domains)", "url"))
    elif hy == 2:
        signals.append(sig("hyphens", 0.07, "النطاق يحتوي شَرطتين", "Domain contains two hyphens", "url"))
    if tld in SUSPICIOUS_TLDS:
        signals.append(sig("suspicious_tld", 0.15, f"امتداد النطاق ‎.{tld}‎ رخيص وشائع في الاحتيال",
                           f"Top-level domain .{tld} is cheap and common in fraud", "url"))
    if v["is_shortener"]:
        signals.append(sig("shortener", 0.2, "رابط مختصر يُخفي الوجهة الحقيقية",
                           "URL shortener hides the real destination", "url"))
    if v["free_hosting"]:
        signals.append(sig("free_hosting", 0.2, "الموقع مستضاف على منصة استضافة مجانية تُستغل كثيراً في التصيّد",
                           "Hosted on a free hosting platform frequently abused for phishing", "url",
                           detail=suffix))
    words = [w for w in SENSITIVE_WORDS if w in lower]
    if len(words) >= 2:
        signals.append(sig("sensitive_words", 0.2, f"كلمات حساسة في الرابط: {', '.join(words[:5])}",
                           f"Sensitive words in URL: {', '.join(words[:5])}", "url"))
    elif len(words) == 1:
        signals.append(sig("sensitive_word", 0.08, f"كلمة حساسة في الرابط: {words[0]}",
                           f"Sensitive word in URL: {words[0]}", "url"))
    if len(url) > 120:
        signals.append(sig("long_url", 0.08, f"رابط طويل جداً ({len(url)} حرفاً)",
                           f"Very long URL ({len(url)} characters)", "url"))
    if v["has_port"]:
        signals.append(sig("odd_port", 0.15, "الرابط يستخدم منفذاً غير معتاد",
                           "URL uses a non-standard port", "url"))
    if url.lower().startswith("http://") and not v["has_ip"]:
        signals.append(sig("no_https", 0.06, "الرابط لا يستخدم HTTPS", "URL does not use HTTPS", "url"))
    label = main_label(reg)
    vowels = sum(c in "aeiou" for c in label) / max(1, len(label))
    digits = sum(c.isdigit() for c in label) / max(1, len(label))
    if (len(label) >= 12 and "-" not in label and shannon_entropy(label) > 3.5
            and (vowels < 0.25 or digits > 0.25) and not is_allowlisted(host, config)):
        signals.append(sig("random_domain", 0.1, "اسم النطاق يبدو عشوائياً (مولَّد آلياً)",
                           "Domain name looks randomly generated", "url"))

    tokens = set(re.split(r"[.\-_0-9]+", host))
    looks_gov = "gov" in tokens or any(t.startswith("gov") and t[3:] in COMBO_WORDS for t in tokens) \
        or any(t.endswith("gov") and t[:-3] in COMBO_WORDS for t in tokens)
    if looks_gov and not suffix.startswith("gov") and suffix != "gov" and not is_allowlisted(host, config):
        signals.append(sig("gov_mimic", 0.35, "النطاق يتظاهر بأنه حكومي لكنه ليس تحت ‎.gov.ae‎",
                           "Domain pretends to be governmental but is not under .gov.ae", "url"))

    matches = brand_matches(host, config)
    if matches and not is_allowlisted(host, config):
        evidence["impersonated_brands"] = [m["brand"]["name_en"] for m in matches]
        for m in matches:
            b = m["brand"]
            off = ", ".join(b["official_domains"][:2])
            kinds = m["kinds"]
            if "typosquat" in kinds or "homoglyph" in kinds:
                signals.append(sig(
                    f"typosquat:{b['id']}", 0.6,
                    f"النطاق مكتوب بطريقة تشبه الموقع الرسمي لـ {b['name_ar']} ({off}) مع تغيير طفيف",
                    f"Look-alike spelling of the official {b['name_en']} domain ({off})", "url"))
            elif "same_name_other_tld" in kinds:
                signals.append(sig(
                    f"same_name:{b['id']}", 0.5,
                    f"نفس اسم {b['name_ar']} لكن بامتداد مختلف عن الرسمي ({off})",
                    f"Same name as {b['name_en']} but a different extension than the official ({off})", "url"))
            else:
                signals.append(sig(
                    f"brand_keyword:{b['id']}", 0.5,
                    f"النطاق يحتوي اسم «{b['name_ar']}» لكنه ليس الموقع الرسمي ({off})",
                    f"Domain contains the name '{b['name_en']}' but is not the official site ({off})", "url"))

    evidence["url_features"] = v
    return signals, evidence
