"""Load config.json and the local settings file that stores optional API keys."""
from __future__ import annotations

import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
SETTINGS_PATH = os.path.join(BASE_DIR, "settings.local.json")

SETTING_KEYS = ["serpapi_key", "gsb_key", "vt_key", "anthropic_key", "anthropic_model"]


def load_config() -> dict:
    with open(CONFIG_PATH, encoding="utf-8") as fh:
        cfg = json.load(fh)
    cfg.setdefault("scan", {})
    cfg.setdefault("brands", [])
    cfg.setdefault("allowlist_domains", [])
    return cfg


def load_settings() -> dict:
    settings = {k: "" for k in SETTING_KEYS}
    try:
        with open(SETTINGS_PATH, encoding="utf-8") as fh:
            settings.update({k: v for k, v in json.load(fh).items() if k in SETTING_KEYS})
    except (OSError, ValueError):
        pass
    # Environment variables override the file (handy for demos / CI).
    for k in SETTING_KEYS:
        env = os.environ.get("RASD_" + k.upper())
        if env:
            settings[k] = env
    return settings


def save_settings(new_values: dict) -> dict:
    current = load_settings()
    for k in SETTING_KEYS:
        if k in new_values and new_values[k] is not None:
            v = str(new_values[k]).strip()
            if v == "__keep__":
                continue
            current[k] = v
    with open(SETTINGS_PATH, "w", encoding="utf-8") as fh:
        json.dump(current, fh, indent=2)
    return current


def public_settings(settings: dict) -> dict:
    """What the UI may see: whether each key is set, never the key itself."""
    return {
        "serpapi_key": bool(settings.get("serpapi_key")),
        "gsb_key": bool(settings.get("gsb_key")),
        "vt_key": bool(settings.get("vt_key")),
        "anthropic_key": bool(settings.get("anthropic_key")),
        "anthropic_model": settings.get("anthropic_model") or "claude-haiku-5-5",
    }
