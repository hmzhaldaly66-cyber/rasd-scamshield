"""Shared helpers: URL/domain parsing and a small, dependency-free HTTP client."""
from __future__ import annotations

import gzip
import ipaddress
import json
import os
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request
import zlib
from typing import Optional

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

# Multi-label public suffixes we care about (small built-in list; no external download needed).
MULTI_PART_SUFFIXES = {
    # UAE
    "gov.ae", "co.ae", "net.ae", "org.ae", "ac.ae", "sch.ae", "mil.ae", "pro.ae", "name.ae",
    # GCC / region
    "com.sa", "gov.sa", "net.sa", "org.sa", "edu.sa", "com.qa", "gov.qa", "com.kw", "gov.kw",
    "com.bh", "gov.bh", "com.om", "gov.om", "co.om", "com.eg", "gov.eg", "com.jo", "gov.jo",
    "com.lb", "com.pk", "gov.pk", "co.in", "gov.in", "net.in", "org.in",
    # Common worldwide
    "co.uk", "org.uk", "gov.uk", "ac.uk", "com.au", "net.au", "gov.au", "co.nz", "co.za",
    "com.br", "com.mx", "com.tr", "gov.tr", "co.jp", "com.cn", "com.hk", "com.sg", "com.my",
    "co.id", "com.ng", "co.ke",
}

# Free hosting / cloud platforms frequently abused for phishing. They behave like public
# suffixes: "evil.netlify.app" is its own site, not part of netlify.app.
HOSTING_SUFFIXES = {
    "netlify.app", "vercel.app", "pages.dev", "workers.dev", "web.app", "firebaseapp.com",
    "github.io", "gitlab.io", "glitch.me", "herokuapp.com", "onrender.com", "repl.co",
    "replit.app", "weebly.com", "wixsite.com", "blogspot.com", "000webhostapp.com",
    "godaddysites.com", "square.site", "webflow.io", "framer.website", "ngrok.io",
    "ngrok-free.app", "r2.dev", "s3.amazonaws.com", "amazonaws.com", "cloudfront.net",
    "azurewebsites.net", "web.core.windows.net", "appspot.com", "translate.goog",
    "sites.google.com", "carrd.co", "wordpress.com", "tilda.ws", "surge.sh", "fly.dev",
    "trycloudflare.com", "duckdns.org", "ddns.net", "no-ip.org",
}

ALL_SUFFIXES = MULTI_PART_SUFFIXES | HOSTING_SUFFIXES


def normalize_url(raw: str) -> Optional[str]:
    """Turn user input like 'example.com/x' into a full http(s) URL, or None if invalid."""
    s = (raw or "").strip().strip("\"'<>()[]")
    if not s:
        return None
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", s):
        s = "http://" + s
    try:
        parts = urllib.parse.urlsplit(s)
    except ValueError:
        return None
    if parts.scheme.lower() not in ("http", "https") or not parts.hostname:
        return None
    host = parts.hostname
    if "." not in host and not is_ip(host):
        return None
    return s


_URL_RE = re.compile(
    r"(?:https?://|www\.)[^\s<>\"'،]+"
    r"|(?<![@\w.\-])[a-z0-9][a-z0-9\-]{1,62}(?:\.[a-z0-9\-]{1,63})*\.[a-z]{2,24}(?::\d{2,5})?(?:/[^\s<>\"'،]*)?",
    re.I,
)


def extract_urls(text: str) -> list[str]:
    """Pull links out of free text (e.g. a pasted SMS). Keeps order, removes duplicates."""
    out: list[str] = []
    for m in _URL_RE.finditer(text or ""):
        u = m.group(0).rstrip(".,;:!?)]}>»؟،")
        if "@" in u.split("/")[0] and not u.lower().startswith("http"):
            continue  # e-mail address, not a link
        if u.lower() not in (x.lower() for x in out):
            out.append(u)
    return out


def hostname(url: str) -> str:
    try:
        host = urllib.parse.urlsplit(url).hostname or ""
    except ValueError:
        host = ""
    return host.lower().rstrip(".")


def is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except ValueError:
        return False


def registered_domain(host: str) -> str:
    """Best-effort eTLD+1 ("www.pay.adpolice.gov.ae" -> "adpolice.gov.ae")."""
    host = host.lower().rstrip(".")
    if not host or is_ip(host):
        return host
    labels = host.split(".")
    for n in range(min(len(labels) - 1, 4), 1, -1):
        suffix = ".".join(labels[-n:])
        if suffix in ALL_SUFFIXES:
            return ".".join(labels[-(n + 1):])
    return ".".join(labels[-2:]) if len(labels) >= 2 else host


def public_suffix(reg_domain: str) -> str:
    """Suffix part of a registered domain ("adpolice.gov.ae" -> "gov.ae")."""
    return reg_domain.split(".", 1)[1] if "." in reg_domain else ""


def main_label(reg_domain: str) -> str:
    """Brand-like label of a registered domain ("adpolice.gov.ae" -> "adpolice")."""
    return reg_domain.split(".", 1)[0]


def subdomain_part(host: str) -> str:
    reg = registered_domain(host)
    if host == reg or not host.endswith("." + reg):
        return ""
    return host[: -(len(reg) + 1)]


def is_hosting_domain(reg_domain: str) -> bool:
    return public_suffix(reg_domain) in HOSTING_SUFFIXES


def host_matches(host: str, domain: str) -> bool:
    """True if host is domain or a subdomain of it."""
    domain = domain.lower().strip(".")
    return host == domain or host.endswith("." + domain)


# --------------------------------------------------------------------------- HTTP client

def _ssl_context(verify: bool = True) -> ssl.SSLContext:
    if not verify:
        return ssl._create_unverified_context()  # noqa: SLF001 - deliberate, read-only analysis
    if os.environ.get("SSL_CERT_FILE"):
        return ssl.create_default_context()
    try:
        import certifi  # optional

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


class _RedirectTracker(urllib.request.HTTPRedirectHandler):
    max_redirections = 8

    def __init__(self) -> None:
        super().__init__()
        self.chain: list[str] = []

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401
        self.chain.append(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _is_cert_error(exc: BaseException) -> bool:
    reason = getattr(exc, "reason", exc)
    return isinstance(reason, ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in str(reason)


def http_request(
    url: str,
    method: str = "GET",
    data: Optional[bytes] = None,
    headers: Optional[dict] = None,
    timeout: float = 15,
    max_bytes: int = 2_000_000,
    allow_tls_fallback: bool = True,
) -> dict:
    """Fetch a URL. Never raises: returns a dict with status/body/error.

    If certificate verification fails and allow_tls_fallback is set, the request is retried
    without verification (read-only) and ``tls_fallback`` is reported, because a broken
    certificate is itself useful evidence when analysing a suspicious site.
    """
    hdrs = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "ar,en;q=0.8",
        "Accept-Encoding": "gzip, deflate",
    }
    if headers:
        hdrs.update(headers)
    result = {"status": None, "url": url, "headers": {}, "body": b"", "redirects": [],
              "tls_fallback": False, "error": None}

    for verify in (True, False):
        tracker = _RedirectTracker()
        opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=_ssl_context(verify)), tracker
        )
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        try:
            try:
                resp = opener.open(req, timeout=timeout)
            except urllib.error.HTTPError as http_err:  # 4xx/5xx still carry a body
                resp = http_err
            raw = resp.read(max_bytes + 1)[:max_bytes]
            enc = (resp.headers.get("Content-Encoding") or "").lower()
            try:
                if "gzip" in enc:
                    raw = gzip.decompress(raw)
                elif "deflate" in enc:
                    raw = zlib.decompress(raw, -zlib.MAX_WBITS)
            except Exception:
                pass  # truncated/odd encoding: keep raw bytes
            result.update(
                status=getattr(resp, "status", None) or getattr(resp, "code", None),
                url=resp.geturl() or url,
                headers={k.lower(): v for k, v in resp.headers.items()},
                body=raw[:max_bytes],
                redirects=tracker.chain,
                tls_fallback=not verify,
                error=None,
            )
            return result
        except Exception as exc:  # noqa: BLE001
            if verify and allow_tls_fallback and _is_cert_error(exc):
                result["error"] = f"TLS verification failed: {getattr(exc, 'reason', exc)}"
                continue
            result["error"] = f"{type(exc).__name__}: {getattr(exc, 'reason', exc)}"
            return result
    return result


def get_json(url: str, headers: Optional[dict] = None, timeout: float = 20,
             data: Optional[dict] = None, method: Optional[str] = None) -> tuple[Optional[object], Optional[str]]:
    """GET/POST JSON. Returns (parsed, error)."""
    body = None
    hdrs = {"Accept": "application/json"}
    if headers:
        hdrs.update(headers)
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    res = http_request(url, method=method or ("POST" if body else "GET"), data=body,
                       headers=hdrs, timeout=timeout, max_bytes=20_000_000)
    if res["error"] and not res["body"]:
        return None, res["error"]
    if res["status"] and res["status"] >= 400:
        return None, f"HTTP {res['status']}: {res['body'][:200].decode('utf-8', 'replace')}"
    try:
        return json.loads(res["body"].decode("utf-8", "replace")), None
    except ValueError as exc:
        return None, f"Invalid JSON: {exc}"


def decode_body(body: bytes, headers: dict) -> str:
    charset = None
    ctype = headers.get("content-type", "")
    m = re.search(r"charset=([\w\-]+)", ctype, re.I)
    if m:
        charset = m.group(1)
    else:
        m = re.search(rb"<meta[^>]+charset=[\"']?([\w\-]+)", body[:4096], re.I)
        if m:
            charset = m.group(1).decode("ascii", "ignore")
    for cs in (charset, "utf-8"):
        if not cs:
            continue
        try:
            return body.decode(cs, errors="replace")
        except LookupError:
            continue
    return body.decode("utf-8", errors="replace")
