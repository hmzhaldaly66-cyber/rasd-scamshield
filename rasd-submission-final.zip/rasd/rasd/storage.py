"""SQLite storage for scans and results (file: data/rasd.db)."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from contextlib import contextmanager

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "data", "rasd.db")
_lock = threading.Lock()


def _conn() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


@contextmanager
def _db():
    c = _conn()
    try:
        with c:
            yield c
    finally:
        c.close()


def init() -> None:
    with _lock, _db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id TEXT PRIMARY KEY, kind TEXT, started_at TEXT, finished_at TEXT,
                status TEXT, summary TEXT
            );
            CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id TEXT, url TEXT, host TEXT,
                registered_domain TEXT, score INTEGER, verdict TEXT, data TEXT, analyzed_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_results_scan ON results(scan_id);
            CREATE INDEX IF NOT EXISTS idx_results_domain ON results(registered_domain);
            """
        )


def save_scan(scan_id: str, kind: str, started_at: str, status: str, summary: dict,
              finished_at: str | None = None) -> None:
    with _lock, _db() as c:
        c.execute(
            "INSERT INTO scans(id, kind, started_at, finished_at, status, summary) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET finished_at=excluded.finished_at, status=excluded.status, "
            "summary=excluded.summary",
            (scan_id, kind, started_at, finished_at, status, json.dumps(summary, ensure_ascii=False)),
        )


def save_result(scan_id: str, r: dict) -> None:
    with _lock, _db() as c:
        c.execute(
            "INSERT INTO results(scan_id, url, host, registered_domain, score, verdict, data, analyzed_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (scan_id, r.get("url"), r.get("host"), r.get("registered_domain"), r.get("score", 0),
             r.get("verdict"), json.dumps(r, ensure_ascii=False), r.get("analyzed_at")),
        )


def list_scans(limit: int = 30) -> list[dict]:
    with _lock, _db() as c:
        rows = c.execute("SELECT * FROM scans ORDER BY started_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r, summary=json.loads(r["summary"] or "{}")) for r in rows]


def get_results(scan_id: str) -> list[dict]:
    with _lock, _db() as c:
        rows = c.execute("SELECT data FROM results WHERE scan_id=? ORDER BY score DESC", (scan_id,)).fetchall()
    return [json.loads(r["data"]) for r in rows]


def first_seen(registered_domain: str) -> str | None:
    with _lock, _db() as c:
        row = c.execute("SELECT MIN(analyzed_at) AS t FROM results WHERE registered_domain=?",
                        (registered_domain,)).fetchone()
    return row["t"] if row else None
