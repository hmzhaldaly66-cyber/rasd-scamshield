"""Exportable evidence reports (printable HTML -> PDF from the browser, and CSV)."""
from __future__ import annotations

import csv
import datetime as dt
import html
import io

SOURCE_NAMES = {
    "manual": ("إدخال يدوي", "Manual input"),
    "ct": ("سجلات الشهادات", "Certificate logs"),
    "typosquat": ("نطاق مشابه", "Look-alike domain"),
    "search": ("نتائج البحث", "Search results"),
    "search_ad": ("إعلان بحث", "Search ad"),
    "maps": ("خرائط Google", "Google Maps"),
}


def _e(x) -> str:
    return html.escape("" if x is None else str(x))


def _defang(url: str) -> str:
    """Make a URL non-clickable in reports: https://evil.com -> hxxps://evil[.]com"""
    return (url or "").replace("http", "hxxp", 1).replace(".", "[.]")


def _ts(iso) -> str:
    s = str(iso or "")
    return (s.replace("T", " ").replace("+00:00", " UTC")[:23]) if s else "—"


def build_html(scan: dict, results: list[dict], lang: str = "ar") -> str:
    ar = lang == "ar"
    t = (lambda a, e: a if ar else e)
    flagged = [r for r in results if r.get("score", 0) >= 40]
    s = scan.get("summary", {}) or {}
    v = s.get("verdicts", {})
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    rows = []
    for i, r in enumerate(flagged, 1):
        ev = r.get("evidence", {}) or {}
        dom = ev.get("domain", {}) or {}
        tls = ev.get("tls", {}) or {}
        reasons = "".join(
            f"<li>{_e(sg['ar'] if ar else sg['en'])}</li>" for sg in r.get("signals", []) if not sg.get("trust") and sg["weight"] > 0
        )
        srcs = "، ".join(SOURCE_NAMES.get(x, (x, x))[0 if ar else 1] for x in r.get("sources", []))
        color = "#b42318" if r["score"] >= 70 else "#b54708"
        rows.append(f"""
        <section class="item">
          <div class="head"><span class="num">#{i}</span>
            <span class="score" style="background:{color}">{r['score']}</span>
            <span class="verdict">{_e(r.get('verdict_ar') if ar else r.get('verdict_en'))}</span>
            <code class="url">{_e(_defang(r.get('url', '')))}</code></div>
          <table class="kv">
            <tr><th>{t('النطاق', 'Domain')}</th><td>{_e(r.get('registered_domain'))}</td>
                <th>{t('عناوين IP', 'IP addresses')}</th><td>{_e(', '.join(ev.get('ips', []) or []) or '—')}</td></tr>
            <tr><th>{t('تاريخ التسجيل', 'Registered')}</th><td>{_e((dom.get('created') or '—')[:10])} {f"({dom['age_days']} {t('يوماً', 'days')})" if dom.get('age_days') is not None else ''}</td>
                <th>{t('المسجّل', 'Registrar')}</th><td>{_e(dom.get('registrar') or '—')}</td></tr>
            <tr><th>{t('جهة إصدار الشهادة', 'TLS issuer')}</th><td>{_e(tls.get('issuer') or ('invalid: ' + tls['error'] if tls.get('error') else '—'))}</td>
                <th>{t('مصدر الاكتشاف', 'Discovered via')}</th><td>{_e(srcs)}</td></tr>
            <tr><th>{t('الوجهة النهائية', 'Final URL')}</th><td colspan="3">{f"<code>{_e(_defang(ev['final_url']))}</code>" if ev.get('final_url') else '—'}</td></tr>
            <tr><th>{t('عنوان الصفحة', 'Page title')}</th><td colspan="3">{_e((ev.get('page') or {}).get('title') or '—')}</td></tr>
            <tr><th>{t('أول رصد', 'First seen')}</th><td colspan="3">{_e(_ts(ev.get('first_seen', r.get('analyzed_at', ''))))}</td></tr>
          </table>
          <div class="reasons"><b>{t('أسباب التصنيف', 'Why it was flagged')}:</b><ul>{reasons}</ul></div>
        </section>""")

    return f"""<!DOCTYPE html>
<html lang="{lang}" dir="{'rtl' if ar else 'ltr'}"><head><meta charset="utf-8">
<title>{t('تقرير رصد', 'Rasd report')} {_e(scan.get('id', ''))}</title>
<style>
 body{{font-family:"Segoe UI",Tahoma,Arial,sans-serif;margin:32px;color:#101828;line-height:1.5}}
 h1{{margin:0 0 4px;font-size:24px}} .muted{{color:#667085;font-size:13px}}
 .cards{{display:flex;gap:12px;margin:20px 0}} .card{{flex:1;border:1px solid #e4e7ec;border-radius:10px;padding:12px}}
 .card b{{font-size:22px;display:block}} .item{{border:1px solid #e4e7ec;border-radius:10px;padding:14px;margin:14px 0;page-break-inside:avoid}}
 .head{{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px}} .num{{color:#667085}}
 .score{{color:#fff;border-radius:6px;padding:2px 10px;font-weight:700}} .verdict{{font-weight:600}}
 code{{direction:ltr;unicode-bidi:embed;background:#f2f4f7;padding:1px 6px;border-radius:4px;word-break:break-all}}
 .kv{{width:100%;border-collapse:collapse;font-size:13px}} .kv th{{text-align:start;color:#475467;font-weight:600;width:14%;padding:4px}}
 .kv td{{padding:4px;border-bottom:1px solid #f2f4f7}} .reasons ul{{margin:6px 0}} .reasons li{{font-size:13px}}
 .note{{background:#fffaeb;border:1px solid #fedf89;border-radius:8px;padding:10px;font-size:13px}}
 @media print{{body{{margin:12mm}} .noprint{{display:none}}}}
</style></head><body>
<h1>🛡️ {t('تقرير رصد للمواقع الاحتيالية', 'Rasd fraudulent website report')}</h1>
<div class="muted">{t('رقم الفحص', 'Scan')} {_e(scan.get('id'))} · {t('بدأ', 'started')} {_e(_ts(scan.get('started_at')))} · {t('أُنشئ التقرير', 'generated')} {now}</div>
<div class="cards">
  <div class="card"><b>{s.get('total', len(results))}</b>{t('رابطاً تم تحليله', 'links analysed')}</div>
  <div class="card" style="border-color:#fda29b"><b style="color:#b42318">{v.get('fraud', 0)}</b>{t('احتيالي على الأرجح', 'likely fraud')}</div>
  <div class="card" style="border-color:#fec84b"><b style="color:#b54708">{v.get('suspicious', 0)}</b>{t('مشبوه', 'suspicious')}</div>
  <div class="card"><b style="color:#067647">{v.get('low', 0) + v.get('official', 0)}</b>{t('منخفض الخطورة / رسمي', 'low risk / official')}</div>
</div>
<p class="note">{t('الروابط في هذا التقرير مُعطَّلة عمداً (hxxp و [.]) لمنع فتحها بالخطأ. الدرجة تقدير آلي يحتاج مراجعة بشرية قبل أي إجراء.',
                  'Links in this report are defanged (hxxp, [.]) to prevent accidental clicks. Scores are automated estimates and need human review before action.')}</p>
<h2>{t('المواقع المُبلَّغ عنها', 'Flagged websites')} ({len(flagged)})</h2>
{''.join(rows) or '<p>' + t('لا توجد مواقع بدرجة خطورة 40 أو أعلى.', 'No websites scored 40 or higher.') + '</p>'}
<p class="noprint muted">{t('للحفظ كملف PDF: اضغط Ctrl+P (أو ⌘P) واختر «حفظ كـ PDF».', 'To save as PDF: press Ctrl+P (or ⌘P) and choose “Save as PDF”.')}</p>
</body></html>"""


def build_csv(results: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["score", "verdict", "url", "final_url", "registered_domain", "sources", "ips",
                "domain_created", "domain_age_days", "registrar", "tls_issuer", "page_title", "first_seen", "reasons"])
    for r in results:
        ev = r.get("evidence", {}) or {}
        dom = ev.get("domain", {}) or {}
        w.writerow([
            r.get("score"), r.get("verdict_en"), r.get("url"), ev.get("final_url", ""), r.get("registered_domain"),
            "|".join(r.get("sources", [])), "|".join(ev.get("ips", []) or []), dom.get("created", ""),
            dom.get("age_days", ""), dom.get("registrar", ""), (ev.get("tls") or {}).get("issuer", ""),
            (ev.get("page") or {}).get("title", ""), ev.get("first_seen", ""),
            " | ".join(s["en"] for s in r.get("signals", []) if not s.get("trust") and s["weight"] > 0),
        ])
    return "﻿" + buf.getvalue()  # BOM so Excel opens Arabic correctly
